#! /bin/bash

chown -R app:app /home/app/webapp
exec "$@"