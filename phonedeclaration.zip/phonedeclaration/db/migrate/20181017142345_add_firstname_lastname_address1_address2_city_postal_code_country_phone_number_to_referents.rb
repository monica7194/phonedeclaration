class AddFirstnameLastnameAddress1Address2CityPostalCodeCountryPhoneNumberToReferents < ActiveRecord::Migration[5.1]
  def change
    add_column :referents, :firstname, :string, null: false
    add_column :referents, :lastname, :string, null: false
    add_column :referents, :address_1, :string, null: false
    add_column :referents, :address_2, :string
    add_column :referents, :city, :string, null: false
    add_column :referents, :postal_code, :string, limit: 5, null: false
    add_column :referents, :country, :string, null: false
    add_column :referents, :phone_number, :string, limit: 10, null: false
  end
end
