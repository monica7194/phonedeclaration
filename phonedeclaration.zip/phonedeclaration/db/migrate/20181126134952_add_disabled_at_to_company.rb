class AddDisabledAtToCompany < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :disabled_at, :datetime
  end
end
