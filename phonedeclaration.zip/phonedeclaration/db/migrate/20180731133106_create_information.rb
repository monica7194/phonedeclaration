class CreateInformation < ActiveRecord::Migration[5.1]
  def change
    create_table :information, id: :uuid do |t|
      t.belongs_to :company, foreign_key: true, type: :uuid
      t.belongs_to :employee, foreign_key: true, type: :uuid
      t.string :firstname
      t.string :lastname

      t.timestamps
    end
  end
end
