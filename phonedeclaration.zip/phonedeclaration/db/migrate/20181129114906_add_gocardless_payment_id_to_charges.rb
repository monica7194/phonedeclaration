class AddGocardlessPaymentIdToCharges < ActiveRecord::Migration[5.1]
  def change
    add_column :charges, :gocardless_payment_id, :string
    change_column :charges, :stripe_charge_id, :string, :null => true
  end
end
