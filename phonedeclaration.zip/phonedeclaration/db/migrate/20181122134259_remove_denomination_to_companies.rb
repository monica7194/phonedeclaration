class RemoveDenominationToCompanies < ActiveRecord::Migration[5.1]
  def change
    remove_column :companies, :denomination
  end
end
