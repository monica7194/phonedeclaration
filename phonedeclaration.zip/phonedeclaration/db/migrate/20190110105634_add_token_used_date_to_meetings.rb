class AddTokenUsedDateToMeetings < ActiveRecord::Migration[5.1]
  def change
    add_column :meetings, :token_used_date, :datetime
    add_column :meetings, :token_expired_date, :datetime
  end
end
