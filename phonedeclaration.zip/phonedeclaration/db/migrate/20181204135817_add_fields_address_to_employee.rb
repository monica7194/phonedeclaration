class AddFieldsAddressToEmployee < ActiveRecord::Migration[5.1]
  def change
    add_column :employees, :sex, :integer
    add_column :employees, :address_1, :string
    add_column :employees, :address_2, :string
    add_column :employees, :city, :string
    add_column :employees, :postal_code, :string
    add_column :employees, :country, :string
    add_column :employees, :birthdate, :date
    add_column :employees, :birthplace, :string
  end
end
