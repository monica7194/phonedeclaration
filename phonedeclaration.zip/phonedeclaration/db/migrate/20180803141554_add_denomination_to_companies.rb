class AddDenominationToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :denomination, :string, null: false, default: ""
  end
end
