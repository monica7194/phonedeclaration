class RemoveLimitInCompanySocialNumber < ActiveRecord::Migration[5.1]
  def change
    change_column :companies, :social_security_number, :string, :limit => nil
  end
end
