class AddLastnameFirstnameSocialSecurityNumberCesuUrssafNumberToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :lastname, :string
    add_column :companies, :firstname, :string
    add_column :companies, :social_security_number, :string, limit: 13
    add_column :companies, :cesu_urssaf_number, :string, limit: 14
  end
end
