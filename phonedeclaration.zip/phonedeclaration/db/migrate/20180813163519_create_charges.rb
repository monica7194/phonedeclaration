class CreateCharges < ActiveRecord::Migration[5.1]
  def change
    create_table :charges, id: :uuid do |t|
      t.belongs_to :company, foreign_key: true, type: :uuid, null: false
      t.string :debitoor_invoice_id, null: false, default: false
      t.string :stripe_charge_id, null: false, default: false
      t.string :name, null: false, default: false
      t.integer :state, null: false, default: false
      t.float :amount, null: false, default: false

      t.timestamps
    end
  end
end
