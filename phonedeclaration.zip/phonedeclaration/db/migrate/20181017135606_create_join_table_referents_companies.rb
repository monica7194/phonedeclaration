class CreateJoinTableReferentsCompanies < ActiveRecord::Migration[5.1]
  def change
    create_join_table :referents, :companies, column_options: {type: :uuid} do |t|
      # t.index [:referent_id, :company_id]
      # t.index [:company_id, :referent_id]
    end
  end
end
