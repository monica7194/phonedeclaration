class AddBirthdateBirthplaceExonerationsToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :birthdate, :date
    add_column :companies, :birthplace, :string
    add_column :companies, :exonerations, :string
  end
end
