class AddStripeCardIdToCompany < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :stripe_card_id, :string, null: false, default: ""
  end
end
