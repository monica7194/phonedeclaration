class AddDisableAtToReferentInfos < ActiveRecord::Migration[5.1]
  def change
    add_column :referent_infos, :disabled_at, :datetime
  end
end
