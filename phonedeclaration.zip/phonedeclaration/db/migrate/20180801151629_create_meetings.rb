class CreateMeetings < ActiveRecord::Migration[5.1]
  def change
    create_table :meetings, id: :uuid do |t|
      t.string :title
      t.datetime :start_date
      t.datetime :end_date
      t.belongs_to :company, foreign_key: true, type: :uuid
      t.belongs_to :planning, foreign_key: true, type: :uuid

      t.timestamps
    end
  end
end
