class CreateAdminPrices < ActiveRecord::Migration[5.1]
  def change
    create_table :admin_prices do |t|
      # t.belongs_to :admin_info, foreign_key: true
      t.float :amount, default: 7.99
      t.integer :amount_type, default: 1
      t.string :amount_for, default: "Société - 10 salariés"
      t.integer :show_order, default: 0
      t.timestamps
    end
  end
end
