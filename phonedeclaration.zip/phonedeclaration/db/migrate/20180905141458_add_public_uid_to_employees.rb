class AddPublicUidToEmployees < ActiveRecord::Migration[5.1]
  def change
    add_column :employees, :public_uid, :string
  end
end
