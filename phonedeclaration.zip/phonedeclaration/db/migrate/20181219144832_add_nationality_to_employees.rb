class AddNationalityToEmployees < ActiveRecord::Migration[5.1]
  def change
    add_column :employees, :nationality, :integer, default: 0
    add_column :companies, :nationality, :integer, default: 0
  end
end
