class AddGocardlessMandateIdToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :gocardless_mandate_id, :string
  end
end
