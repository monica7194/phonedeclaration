class AddAddress1Address2CityPostalCodeCountryPhoneNumberGsmNumberToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :address_1, :string
    add_column :companies, :address_2, :string
    add_column :companies, :city, :string
    add_column :companies, :postal_code, :string, limit: 5
    add_column :companies, :country, :string
    add_column :companies, :phone_number, :string, limit: 10
    add_column :companies, :gsm_number, :string, limit: 10
  end
end
