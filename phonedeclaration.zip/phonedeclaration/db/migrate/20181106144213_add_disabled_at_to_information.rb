class AddDisabledAtToInformation < ActiveRecord::Migration[5.1]
  def change
    add_column :information, :disabled_at, :datetime
  end
end
