class CreatePointingFlyers < ActiveRecord::Migration[5.1]
  def change
    create_table :pointing_flyers, id: :uuid do |t|
      t.timestamps
      t.boolean :job_in_progress, null: false, default: false
      t.belongs_to :meeting, foreign_key: true, type: :uuid, null: false
      t.belongs_to :employee, foreign_key: true, type: :uuid, null: false
    end
  end
end
