class AddTokenToMeetings < ActiveRecord::Migration[5.1]
  def change
    add_column :meetings, :token, :string
  end
end
