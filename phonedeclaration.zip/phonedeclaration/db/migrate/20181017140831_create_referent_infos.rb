class CreateReferentInfos < ActiveRecord::Migration[5.1]
  def change
    create_table :referent_infos, id: :uuid do |t|

      t.string :relation
      t.belongs_to :referent, type: :uuid, index: true
      t.belongs_to :company, type: :uuid, index: true
      t.timestamps
    end
  end
end
