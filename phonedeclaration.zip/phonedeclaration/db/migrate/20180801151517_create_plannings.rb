class CreatePlannings < ActiveRecord::Migration[5.1]
  def change
    create_table :plannings, id: :uuid do |t|
      t.belongs_to :employee, foreign_key: true, type: :uuid

      t.timestamps
    end
  end
end
