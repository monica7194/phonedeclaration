class AddDayOffReasonToMeetings < ActiveRecord::Migration[5.1]
  def change
    add_column :meetings, :day_off_reason, :integer, default: 0
  end
end
