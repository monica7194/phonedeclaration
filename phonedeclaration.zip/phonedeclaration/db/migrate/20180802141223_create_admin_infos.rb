class CreateAdminInfos < ActiveRecord::Migration[5.1]
  def change
    create_table :admin_infos do |t|
      t.string :debitoor_payment_account_id
      t.string :debitoor_payment_account_name

      t.timestamps
    end
  end
end
