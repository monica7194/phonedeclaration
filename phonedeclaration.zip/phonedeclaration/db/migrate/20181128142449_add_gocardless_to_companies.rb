class AddGocardlessToCompanies < ActiveRecord::Migration[5.1]
  def change
    add_column :companies, :gocardless_customer_id, :string
    add_column :companies, :gocardless_bank_id, :string
  end
end
