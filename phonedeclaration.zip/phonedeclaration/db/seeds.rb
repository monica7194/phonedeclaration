# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

if AdminPrice.count == 0
  AdminPrice.create(amount_for: "Prix fixe", amount: 0, amount_type: 0, show_order: 1)
  AdminPrice.create(amount_for: "Société - 10 salariés", amount: 7.99, amount_type: 1, show_order: 2)
  AdminPrice.create(amount_for: "Société 10 - 20 salariés", amount: 7.19, amount_type: 1, show_order: 3)
  AdminPrice.create(amount_for: "Société 21 - 50 salariés", amount: 6.79, amount_type: 1, show_order: 4)
  AdminPrice.create(amount_for: "Société 51 - 100 salariés", amount: 6, amount_type: 1, show_order: 5)
  AdminPrice.create(amount_for: "Société 100 - 300 salariés", amount: 5, amount_type: 1, show_order: 6)
  AdminPrice.create(amount_for: "Société + 300 salariés", amount: 4, amount_type: 1, show_order: 7)
end
