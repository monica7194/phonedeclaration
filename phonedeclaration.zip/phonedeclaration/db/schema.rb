# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20190110105634) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"
  enable_extension "uuid-ossp"
  enable_extension "pgcrypto"

  create_table "admin_infos", force: :cascade do |t|
    t.string "debitoor_payment_account_id"
    t.string "debitoor_payment_account_name"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "admin_prices", force: :cascade do |t|
    t.float "amount", default: 7.99
    t.integer "amount_type", default: 1
    t.string "amount_for", default: "Société - 10 salariés"
    t.integer "show_order", default: 0
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "admins", id: :uuid, default: -> { "uuid_generate_v4()" }, force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "firstname"
    t.string "lastname"
    t.index ["email"], name: "index_admins_on_email", unique: true
    t.index ["reset_password_token"], name: "index_admins_on_reset_password_token", unique: true
  end

  create_table "charges", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "company_id", null: false
    t.string "debitoor_invoice_id", default: "f", null: false
    t.string "stripe_charge_id", default: "f"
    t.string "name", default: "f", null: false
    t.integer "state", default: 0, null: false
    t.float "amount", default: 0.0, null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "gocardless_payment_id"
    t.index ["company_id"], name: "index_charges_on_company_id"
  end

  create_table "companies", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.string "color"
    t.string "debitoor_customer_id"
    t.string "stripe_customer_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "stripe_card_id", default: "", null: false
    t.string "lastname"
    t.string "firstname"
    t.string "social_security_number"
    t.string "cesu_urssaf_number", limit: 14
    t.string "address_1"
    t.string "address_2"
    t.string "city"
    t.string "postal_code", limit: 5
    t.string "country"
    t.string "phone_number", limit: 10
    t.string "gsm_number", limit: 10
    t.date "birthdate"
    t.string "birthplace"
    t.string "exonerations"
    t.string "public_uid"
    t.boolean "rgpd_agreement", default: false, null: false
    t.boolean "cgv_agreement", default: false, null: false
    t.datetime "disabled_at"
    t.string "gocardless_customer_id"
    t.string "gocardless_bank_id"
    t.string "gocardless_mandate_id"
    t.integer "nationality", default: 0
    t.index ["email"], name: "index_companies_on_email", unique: true
    t.index ["reset_password_token"], name: "index_companies_on_reset_password_token", unique: true
  end

  create_table "companies_referents", id: false, force: :cascade do |t|
    t.uuid "referent_id", null: false
    t.uuid "company_id", null: false
  end

  create_table "employees", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.string "social_security_number", null: false
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "phone_number"
    t.string "public_uid"
    t.integer "sex"
    t.string "address_1"
    t.string "address_2"
    t.string "city"
    t.string "postal_code"
    t.string "country"
    t.date "birthdate"
    t.string "birthplace"
    t.integer "nationality", default: 0
    t.index ["email"], name: "index_employees_on_email", unique: true
    t.index ["reset_password_token"], name: "index_employees_on_reset_password_token", unique: true
  end

  create_table "information", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "company_id"
    t.uuid "employee_id"
    t.string "firstname"
    t.string "lastname"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "delay_margin"
    t.datetime "disabled_at"
    t.index ["company_id"], name: "index_information_on_company_id"
    t.index ["employee_id"], name: "index_information_on_employee_id"
  end

  create_table "meetings", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "title"
    t.datetime "start_date"
    t.datetime "end_date"
    t.uuid "company_id"
    t.uuid "planning_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer "state", default: 1
    t.integer "day_off_reason", default: 0
    t.string "token"
    t.datetime "token_used_date"
    t.datetime "token_expired_date"
    t.index ["company_id"], name: "index_meetings_on_company_id"
    t.index ["planning_id"], name: "index_meetings_on_planning_id"
  end

  create_table "plannings", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.uuid "employee_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.index ["employee_id"], name: "index_plannings_on_employee_id"
  end

  create_table "pointing_flyers", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean "job_in_progress", default: false, null: false
    t.uuid "meeting_id", null: false
    t.uuid "employee_id", null: false
    t.index ["employee_id"], name: "index_pointing_flyers_on_employee_id"
    t.index ["meeting_id"], name: "index_pointing_flyers_on_meeting_id"
  end

  create_table "referent_infos", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "relation"
    t.uuid "referent_id"
    t.uuid "company_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.datetime "disabled_at"
    t.index ["company_id"], name: "index_referent_infos_on_company_id"
    t.index ["referent_id"], name: "index_referent_infos_on_referent_id"
  end

  create_table "referents", id: :uuid, default: -> { "gen_random_uuid()" }, force: :cascade do |t|
    t.string "email", default: "", null: false
    t.string "encrypted_password", default: "", null: false
    t.string "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer "sign_in_count", default: 0, null: false
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.inet "current_sign_in_ip"
    t.inet "last_sign_in_ip"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string "firstname", null: false
    t.string "lastname", null: false
    t.string "address_1", null: false
    t.string "address_2"
    t.string "city", null: false
    t.string "postal_code", limit: 5, null: false
    t.string "country", null: false
    t.string "phone_number", limit: 10, null: false
    t.index ["email"], name: "index_referents_on_email", unique: true
    t.index ["reset_password_token"], name: "index_referents_on_reset_password_token", unique: true
  end

  add_foreign_key "charges", "companies"
  add_foreign_key "information", "companies"
  add_foreign_key "information", "employees"
  add_foreign_key "meetings", "companies"
  add_foreign_key "meetings", "plannings"
  add_foreign_key "plannings", "employees"
  add_foreign_key "pointing_flyers", "employees"
  add_foreign_key "pointing_flyers", "meetings"
end
