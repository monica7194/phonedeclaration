require "application_system_test_case"

class PointingFlyersTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pointing_flyers_url
  #
  #   assert_selector "h1", text: "PointingFlyer"
  # end
end
