require 'test_helper'

class Companies::EmployeesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get companies_employees_index_url
    assert_response :success
  end

end
