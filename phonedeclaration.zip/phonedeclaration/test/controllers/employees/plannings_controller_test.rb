require 'test_helper'

class Employees::PlanningsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get employees_plannings_index_url
    assert_response :success
  end

end
