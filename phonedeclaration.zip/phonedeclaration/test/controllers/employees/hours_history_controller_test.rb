require 'test_helper'

class Employees::HoursHistoryControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
