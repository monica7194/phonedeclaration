require 'test_helper'

class AdminInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
