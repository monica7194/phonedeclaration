require 'test_helper'

class PointingFlyerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
