require 'test_helper'

class ReferentInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
