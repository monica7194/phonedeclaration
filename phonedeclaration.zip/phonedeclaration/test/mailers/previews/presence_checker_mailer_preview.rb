# Preview all emails at http://localhost:3000/rails/mailers/presence_checker_mailer
class PresenceCheckerMailerPreview < ActionMailer::Preview

end
