require 'test_helper'

class PresenceCheckerMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
