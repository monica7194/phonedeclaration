Rails.application.routes.draw do

  devise_for :referents, controllers: { sessions: 'referents/sessions', registrations: 'referents/registrations' }
  devise_for :admins
  devise_for :employees
  devise_scope :company do
    post '/companies/disabled', to: 'companies_registration/registrations#disabled', as: 'disabled_company_registration'
  end
  devise_for :companies, controllers: { registrations: 'companies_registration/registrations'}

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  namespace :companies do
    resources :informations, except: [:show] do
      resources :plannings, only: [:show]
      resources :meetings, only: [:create, :update, :destroy]
      resources :pointing_flyers, only: [:index]
      member do
        post :disabled
      end
    end
    get "/employees/social_number", to: "informations#employee_by_social_number", as: "employee_by_social_number"
    get "/companies/social_number", to: "informations#company_by_social_number", as: "company_by_social_number"
    get '/companies/informations/pointing_flyers/all', to: 'pointing_flyers#all', as: 'companies_all_pointing_flyers'
    resources :charges
    resources :billings do
      member do
        post :download_invoice
      end
    end
    resources :referents, except: [:show]
    resources :plannings, only: [:index]
    resources :meetings, only: [:create, :update, :destroy]
  end

  namespace :employees do
    resources :plannings, only: [:index]
    resources :meetings, only: [:create, :update, :destroy] do
      member do
        get :accepted
        get :refused
      end
      collection do
        patch :sick_leave
      end
    end
    resources :pointing_flyers
    resources :companies, only: [:index]
    resources :hours_history, only: [:index, :show]
  end

  resources :employees, only: [:edit, :update] do
    match '/', action: 'edit', :via => [:get]
  end
  namespace :admins do
    resources :admins, except: [:show]
    resources :admin_prices, except: [:show]
    resources :companies do
      resources :employees
      resources :referents
      member do
        get :billings
      end
    end

    resources :employees do
      resources :pointing_flyers, only: [:index, :destroy, :edit, :update, :new, :create]
      member do
        get :hours_history
        get :pointing_flyers
      end
    end
    resources :referents, except: [:show]
    resources :charges, only: [:index]
  end

  root 'home#index'
  get '/cgv', to: 'home#cgv', as: 'home_cgv'

  get '/public/referent/companies', to: 'home#referent_companies', as: 'public_referent_companies'
  get '/public/employees/:phone_number/:login_number/login', to: 'home#svi_employee_login_number', as: 'public_svi_employee_login_number'
  get '/public/companies/:phone_number/:login_number/login', to: 'home#svi_company_login_number', as: 'public_svi_company_login_number'
  get '/public/employees/:phone_number/:login_number/pointing/start', to: 'home#employee_pointing_flyer_start', as: 'public_employee_pointing_flyer_start'
  get '/public/employees/:phone_number/:login_number/pointing/end', to: 'home#employee_pointing_flyer_end', as: 'public_employee_pointing_flyer_end'

  get '/public/employees/:phone_number', to: 'home#employee_phone_number', as: 'public_employee_phone_number'
  get '/public/employees/:phone_number/:login_number', to: 'home#employee_login_number', as: 'public_employee_login_number'
  get '/public/companies/:phone_number/:login_number', to: 'home#company_login_number', as: 'public_company_login_number'
  get '/public/employees/:phone_number/:login_number/meeting', to: 'home#employee_current_meeting', as: 'public_employee_current_meeting'
  get '/public/employees/:phone_number/:login_number/pointing', to: 'home#employee_pointing_flyer', as: 'public_employee_pointing_flyer'
  get '/public/employees/:phone_number/:company_login_number/:employee_login_number/pointings/last5', to: 'home#company_employee_pointing_last5', as: 'public_company_employee_pointing_last5'
  get '/public/employees/:phone_number/:company_login_number/:employee_login_number/pointings/last', to: 'home#company_employee_pointing_last', as: 'public_company_employee_pointing_last'
  get '/public/employees/:phone_number/:company_login_number/:employee_login_number/pointings/current', to: 'home#company_employee_pointing_current', as: 'public_company_employee_pointing_current'
  get '/public/employees/:phone_number/:company_login_number/:employee_login_number/pointings/next', to: 'home#company_employee_pointing_next', as: 'public_company_employee_pointing_next'

  get '/public/company/:phone_number/:login_number/login', to: 'home#svi_company_data', as: 'public_svi_company_data'
  get '/public/employee/:phone_number/:login_number/login', to: 'home#svi_employee_data', as: 'public_svi_employee_data'
  get '/public/employee/:phone_number/:login_number/dayoff/sick', to: 'home#svi_sick_dayoff', as: 'public_svi_employee_sick_dayoff'
  get '/public/employee/:phone_number/:login_number/dayoff/vacation', to: 'home#svi_vacation_dayoff', as: 'public_svi_employee_vacation_dayoff'
end
