class AdminsChargesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  include ApplicationHelper
  def initialize(view)
    @view = view

  end

  def as_json(options = {})
    {
        sEcho: params[:sEcho].to_i,
        iTotalRecords: charges.count,
        iTotalDisplayRecords: charges.total_entries,
        aaData: data
    }
  end

  private

  def data
    charges.map do |charge|
      [
          charge.company.fullname,
          number_to_currency(charge.amount),
          charge.created_at.strftime("%d/%m/%Y %H:%M:%S"),
          link_to(raw("Télécharger"), download_invoice_companies_billing_path(charge.id), class: "btn btn-icon", "chargeId"=> charge.id, method: :post)
      ]
    end
  end

  def charges
    @charges ||= fetch_charges
  end

  def fetch_charges
    charges = Charge.includes(:company).order("#{sort_column} #{sort_direction}")
    charges = charges.page(page).per_page(per_page)
    if params[:sSearch].present?
      charges = charges.where('LOWER(companies.lastname) LIKE LOWER(:search) OR LOWER(companies.firstname) LIKE LOWER(:search) OR LOWER(amount) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    charges
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[companies.firstname amount created_at updated_at]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "asc" ? "asc" : "desc"
  end
end
