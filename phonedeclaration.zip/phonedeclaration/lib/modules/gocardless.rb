module Gocardless
  @token = ENV['gocardless_token']
  if ENV["gocardless_env"] == "sandbox"
    @client = GoCardlessPro::Client.new(
      access_token: @token,
      environment: :sandbox
      # environment: Rails.env.development? ? :sandbox : nil
    )
  else
    @client = GoCardlessPro::Client.new(
      access_token: @token
    )
  end

  def self.create_customer given_name, family_name, email
    @client.customers.create(
      params: {
        given_name: given_name,
        family_name: family_name,
        email: email
      }
    )
  end
  def self.get_customer gocardless_customer_id
    @client.customers.get(gocardless_customer_id)
  end

  def self.create_bank account_holder_name, iban, gocardless_customer_id
    @client.customer_bank_accounts.create(
      params: {
        account_holder_name: account_holder_name,
        iban: iban,
        links: {
          customer: gocardless_customer_id
        }
      }
    )
  end
  def self.get_bank gocardless_bank_id
    @client.customer_bank_accounts.get(gocardless_bank_id)
  end
  def self.disable_bank company
    @client.customer_bank_accounts.disable(company.gocardless_bank_id)
    company.update gocardless_bank_id: nil, gocardless_mandate_id: nil
  end
  def self.create_mandate gocardless_bank_id
    @client.mandates.create(
      params: {
        links: {
          customer_bank_account: gocardless_bank_id
        }
      }
    )
  end
  def self.create_payment amount, description, gocardless_mandate_id, currency="EUR"
    @client.payments.create(
      params: {
        amount: amount,
        currency: currency,
        description: description,
        links: {
           mandate: gocardless_mandate_id
         }
      }
    )
  end
  def self.get_payment gocardless_payment_id
    @client.payments.get(gocardless_payment_id)
  end
end