class CompaniesPointingFlyersDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  include ApplicationHelper
  def initialize(view, is_admin = false, company = nil)
    @view = view
    @is_admin = is_admin
    @company = company
  end

  def as_json(options = {})
    {
        sEcho: params[:sEcho].to_i,
        iTotalRecords: pointing_flyers.count,
        iTotalDisplayRecords: pointing_flyers.total_entries,
        aaData: data
    }
  end

  private

  def data
    if @is_admin
      pointing_flyers.map do |pointing_flyer|
        # delay_start = pointing_flyer.created_at - (pointing_flyer.meeting.start_date + pointing_flyer.employee.informations[0].delay_margin.minute)
        # delay_end = time_diff((pointing_flyer.meeting.end_date + pointing_flyer.employee.informations[0].delay_margin.minute), pointing_flyer.updated_at)
        span_delete = link_to(raw("<i class='fa fa-trash'></i>"), admins_employee_pointing_flyer_path(employee_id: pointing_flyer.employee_id, id: pointing_flyer.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet employeur ?"}, class: "btn btn-icon", id: "delete-pointing_flyer-#{pointing_flyer.id}" )
        span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_employee_pointing_flyer_path(employee_id: pointing_flyer.employee_id, id: pointing_flyer.id), class: "btn btn-icon", "pointing_flyerId"=> pointing_flyer.id, method: :get)
        [
            pointing_flyer.meeting.title,
            # pointing_flyer.meeting.start_date.strftime("%d/%m/%Y %H:%M:%S"),
            # pointing_flyer.meeting.end_date.strftime("%d/%m/%Y %H:%M:%S"),
            pointing_flyer.created_at.strftime("%d/%m/%Y %H:%M:%S"),
            pointing_flyer.updated_at.strftime("%d/%m/%Y %H:%M:%S"),
            ((pointing_flyer.late? ? "<div class='text-danger'>#{second_diff(pointing_flyer.late_time_abs)}</div>" : '') rescue nil ),
            ((pointing_flyer.over_work? ? "<div class=\"text-danger\">" + second_diff(pointing_flyer.over_work_time.abs) + "</div>" : '') rescue nil),
            pointing_flyer.job_in_progress ? time_diff(Time.now, pointing_flyer.created_at) : time_diff(pointing_flyer.updated_at, pointing_flyer.created_at),
            # pointing_flyer.job_in_progress ? 'En cours' : 'Terminée',
            "<div class=''>#{span_edit}#{span_delete}</div>"
        ]
      end
    else
      pointing_flyers.map do |pointing_flyer|
        # delay_start = pointing_flyer.created_at - (pointing_flyer.meeting.start_date + pointing_flyer.employee.informations[0].delay_margin.minute)
        # delay_end = time_diff((pointing_flyer.meeting.end_date + pointing_flyer.employee.informations[0].delay_margin.minute), pointing_flyer.updated_at)

        delay_margin = pointing_flyer.employee.informations[0].delay_margin.present? ? pointing_flyer.employee.informations[0].delay_margin : 2
        [
            pointing_flyer.meeting.title,
            # pointing_flyer.meeting.start_date.strftime("%d/%m/%Y %H:%M:%S"),
            # pointing_flyer.meeting.end_date.strftime("%d/%m/%Y %H:%M:%S"),
            pointing_flyer.created_at.strftime("%d/%m/%Y %H:%M:%S"),
            pointing_flyer.updated_at.strftime("%d/%m/%Y %H:%M:%S"),
            (pointing_flyer.meeting.start_date + delay_margin.minute) <= pointing_flyer.created_at ? "<div class=\"text-danger\">" + time_diff(pointing_flyer.created_at, (pointing_flyer.meeting.start_date + delay_margin.minute)) + "</div>" : '',
            (pointing_flyer.meeting.end_date + delay_margin.minute) <= pointing_flyer.updated_at ? "<div class=\"text-danger\">" + time_diff(pointing_flyer.updated_at, (pointing_flyer.meeting.end_date + delay_margin.minute)) + "</div>" : '',
            pointing_flyer.job_in_progress ? time_diff(Time.now, pointing_flyer.created_at) : time_diff(pointing_flyer.updated_at, pointing_flyer.created_at),
            pointing_flyer.job_in_progress ? 'En cours' : 'Terminée'
        ]
      end
    end
  end

  def pointing_flyers
    @pointing_flyers ||= fetch_pointing_flyers
  end

  def fetch_pointing_flyers
    if @company.present?
      if params[:range_start].present? && params[:range_end].present?
        pointing_flyers = PointingFlyer
                               .includes(meeting: [:company]).references(:meeting)
                               .includes(employee: :informations)
                               .references(employee: :informations)
                               .where(employee: {information: {id: params[:information_id]}})
                               .where(companies: {id: @company.id})
                               .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                               .order("#{sort_column} #{sort_direction}")
      else
        pointing_flyers = PointingFlyer
                               .includes(meeting: [:company]).references(:meeting)
                               .includes(employee: :informations)
                               .references(employee: :informations)
                               .where(employee: {information: {id: params[:information_id]}})
                               .where(companies: {id: @company.id})
                               .order("#{sort_column} #{sort_direction}")
      end
    else
      if params[:range_start].present? && params[:range_end].present?
        pointing_flyers = PointingFlyer
                               .includes(meeting: [:company]).references(:meeting)
                               .includes(employee: :informations)
                               .references(employee: :informations)
                               .where(employee: {information: {id: params[:information_id]}})
                               .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                               .order("#{sort_column} #{sort_direction}")
      else
        pointing_flyers = PointingFlyer
                               .includes(meeting: [:company]).references(:meeting)
                               .includes(employee: :informations)
                               .references(employee: :informations)
                               .where(employee: {information: {id: params[:information_id]}})
                               .order("#{sort_column} #{sort_direction}")
      end
    end

    pointing_flyers = pointing_flyers.page(page).per_page(per_page)
    if params[:sSearch].present?
      pointing_flyers = pointing_flyers.where('LOWER(meetings.title) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    pointing_flyers
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[meetings.title pointing_flyers.created_at pointing_flyers.updated_at]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "asc" ? "asc" : "desc"
  end
end
