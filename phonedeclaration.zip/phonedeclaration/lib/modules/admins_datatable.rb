class AdminsDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view)
    @view = view
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords:Admin.count,
      iTotalDisplayRecords: admins.total_entries,
      aaData: data
    }
  end

private

  def data
    admins.map do |admin|
      delete_admin = link_to(raw("<i class='fa fa-trash'></i>"), admins_admin_path(admin.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet administrateur ?"}, class: "btn btn-icon", id: "delete-admin-#{admin.id}" )
      span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_admin_path(admin.id), class: "btn btn-icon", "adminId"=> admin.id, method: :get)
      [
        admin.firstname,
        admin.lastname,
        admin.email,
        "<div class=''>#{span_edit}#{delete_admin}</div>"
      ]
    end
  end

  def admins
    @admins ||= fetch_admins
  end

  def fetch_admins
    admins = Admin.page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    if params[:sSearch].present?
      admins = admins.where('LOWER(admins.email) LIKE LOWER(:search) OR LOWER(admins.firstname) LIKE LOWER(:search) OR LOWER(admins.lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    admins
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[admins.email admins.firstname admins.lastname]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
