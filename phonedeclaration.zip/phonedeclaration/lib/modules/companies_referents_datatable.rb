class CompaniesReferentsDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view, company, referent)
    @view = view
    @company = company
    @referent = referent
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: @company.referents.count,
      iTotalDisplayRecords: referents.total_entries,
      aaData: data
    }
  end

private

  def data
    referents.map do |referent|
      span_edit = @referent.present? ? '' : link_to(raw("<i class='fa fa-pencil'></i>"), edit_companies_referent_path(referent.id), class: "btn btn-icon", "referentId"=> referent.id, method: :get)
      referent_info = referent.referent_infos.detect{|r_i| r_i.company_id == @company.id}
      delete_referent = @referent.present? ? '' : link_to(raw("<i class='fa fa-#{referent_info.not_disabled? ? "check" : "close"}'></i>"), companies_referent_path(referent.id), method: :delete, data: { confirm: "Voulez-vous #{referent_info.not_disabled? ? "désactiver" : "activer"} ce référent ?"}, class: "btn btn-icon", id: "delete-referent-#{referent.id}" )
      [
          referent.lastname,
          referent.firstname,
          referent.email,
          (human_readable_relation(referent_info.relation) if referent_info.present?),
        "<div class=''>#{span_edit}#{delete_referent}</div>"
      ]
    end
  end

  def referents
    @referents ||= fetch_referents
  end

  def fetch_referents
    referents = @company.referents.includes(:referent_infos).where(referent_infos: {company_id: @company.id}).order("#{sort_column} #{sort_direction}").distinct
    referents = referents.page(page).per_page(per_page)
    if params[:sSearch].present?
      referents = referents.where('LOWER(email) LIKE LOWER(:search) OR LOWER(firstname) LIKE LOWER(:search) OR LOWER(lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    referents
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[email firstname lastname]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end

  def human_readable_relation(relation)
    relation_options = {
        BROTHER: I18n.t("other.relation.brother"),
        SISTER: I18n.t("other.relation.sister"),
        FATHER: I18n.t("other.relation.father"),
        MOTHER: I18n.t("other.relation.mother"),
        GRAND_PARENT: I18n.t("other.relation.grand_parent"),
        SOCIAL_WORKER: I18n.t("other.relation.social_worker"),
        PERSONAL_SERVICE_COMPANY: I18n.t("other.relation.personal_service_company")
    }
    relation_options[:"#{relation}"]
  end
end
