class AdminsEmployeesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view)
    @view = view
  end

  def as_json(options = {})
    if params[:company_id].present?
      total_records = Employee.joins(:companies).where(companies: {id: params[:company_id]}).distinct.count
    else
      total_records = Employee.count
    end
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: total_records,
      iTotalDisplayRecords: employees.total_entries,
      aaData: data
    }
  end

private

  def data
    employees.map do |employee|
      if params[:company_id].present?
        information = employee.informations.find_by(company_id: params[:company_id])
        delete_employee = link_to(raw("<i class='fa fa-#{information.not_disabled? ? "check" : "close"}'></i>"), disabled_companies_information_path(information.id), remote: true, method: :post, data: { confirm: "Voulez-vous #{information.not_disabled? ? "désactiver" : "activer"} cet employé ?"}, class: "btn btn-icon", id: "delete-employee-#{employee.id}" )
      else
        delete_employee = link_to(raw("<i class='fa fa-trash'></i>"), admins_employee_path(employee.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet employé ?"}, class: "btn btn-icon", id: "delete-employee-#{employee.id}" )
      end
      span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_employee_path(id: employee.id, company_id: params[:company_id]), class: "btn btn-icon", "employeeId"=> employee.id, method: :get)
      span_planning = link_to(raw("<i class='fa fa-calendar'></i>"), admins_employee_path(employee.id), class: "btn btn-icon", "employeeId"=> employee.id, method: :get)
      span_hours_history = link_to(raw("<i class='fa fa-tachometer'></i>"), hours_history_admins_employee_path(employee.id), class: "btn btn-icon", "employeeId"=> employee.id, method: :get)
      span_pointing_flyers = link_to(raw("<i class='fa fa-clock-o'></i>"), pointing_flyers_admins_employee_path(employee.id), class: "btn btn-icon", "employeeId"=> employee.id, method: :get)
      if params[:company_id].present?
        [
          employee.email,
          (params[:company_id].present? ? employee.companies.count : employee.companies.length),
          (employee.planning.present? ? employee.planning.meetings.select{|m| m.company_id == params[:company_id]}.length : 0),
          "<div class=''>#{span_edit}#{span_planning}#{span_pointing_flyers}#{span_hours_history}#{delete_employee}</div>"
        ]
      else
        [
          employee.email,
          (params[:company_id].present? ? employee.companies.count : employee.companies.length),
          (employee.planning.present? ? employee.planning.meetings.length : 0),
          "<div class=''>#{span_edit}#{span_planning}#{span_pointing_flyers}#{span_hours_history}#{delete_employee}</div>"
        ]
      end

    end
  end

  def employees
    @employees ||= fetch_employees
  end

  def fetch_employees
    if params[:company_id].present?
      employees = Employee.includes(:pointing_flyers, :companies, :informations, :planning => [:meetings]).references(:companies).where(companies: {id: params[:company_id]}).page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    else
      employees = Employee.includes(:pointing_flyers, :companies, :planning => [:meetings]).page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    end
    if params[:sSearch].present?
      employees = employees.where('LOWER(employees.email) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    employees
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[employees.email employees.email employees.email employees.email]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
