class AdminPricesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view)
    @view = view
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: AdminPrice.count,
      iTotalDisplayRecords: admin_prices.total_entries,
      aaData: data
    }
  end

private

  def data
    admin_prices.map do |admin_price|
      delete_admin_price = link_to(raw("<i class='fa fa-trash'></i>"), admins_admin_price_path(admin_price.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet utilisateur ?"}, class: "btn btn-icon", id: "delete-admin_price-#{admin_price.id}" )
      span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_admin_price_path(id: admin_price.id, company_id: params[:company_id]), class: "btn btn-icon", "admin_priceId"=> admin_price.id, method: :get)
      [
        I18n.t("other.amount_type.#{AdminPrice::AMOUNT_TYPES.key admin_price.amount_type}"),
        admin_price.amount_for,
        number_to_currency(admin_price.amount),
        admin_price.show_order,
        "<div class=''>#{span_edit}#{delete_admin_price}</div>"
      ]
    end
  end

  def admin_prices
    @admin_prices ||= fetch_admin_prices
  end

  def fetch_admin_prices
    admin_prices = AdminPrice.page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    if params[:sSearch].present?
      # admin_prices = admin_prices.where('LOWER(admin_prices.email) LIKE LOWER(:search) OR LOWER(admin_prices.firstname) LIKE LOWER(:search) OR LOWER(admin_prices.lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    admin_prices
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[admin_prices.amount_type admin_prices.amount_for admin_prices.amount admin_prices.show_order]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
