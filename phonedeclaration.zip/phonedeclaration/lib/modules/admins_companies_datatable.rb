class AdminsCompaniesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view)
    @view = view
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords:Company.count,
      iTotalDisplayRecords: companies.total_entries,
      aaData: data
    }
  end

private

  def data
    companies.map do |company|
      delete_company = link_to(raw("<i class='fa fa-#{company.not_disabled? ? "check" : "close"}'></i>"), admins_company_path(company.id), remote: true, method: :delete, data: { confirm: "Voulez-vous #{company.not_disabled? ? "désactiver" : "activer"} cet employeur ?"}, class: "btn btn-icon", id: "delete-company-#{company.id}" )
      span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_company_path(company.id), class: "btn btn-icon", "companyId"=> company.id, method: :get)
      span_planning = link_to(raw("<i class='fa fa-calendar'></i>"), admins_company_path(company.id), class: "btn btn-icon", "companyId"=> company.id, method: :get)
      span_billing = link_to(raw("<i class='fa fa-dollar'></i>"), billings_admins_company_path(company.id), class: "btn btn-icon", "companyId"=> company.id, method: :get)
      span_employees = link_to(raw("<i class='fa fa-users'></i>"), admins_company_employees_path(company.id), class: "btn btn-icon", "companyId"=> company.id, method: :get)
      span_referents = link_to(raw("<i class='fa fa-user'></i>"), admins_company_referents_path(company.id), class: "btn btn-icon", "companyId"=> company.id, method: :get)
      [
        company.email,
        company.firstname,
        company.lastname,
        company.informations.length,
        company.total_missions,
        company.referents.length,
        I18n.t("other.boolean.#{!company.disabled?}"),
        "<div class=''>#{span_edit}#{span_employees}#{span_planning}#{span_billing}#{span_referents}#{delete_company}</div>"
      ]
    end
  end

  def companies
    @companies ||= fetch_companies
  end

  def fetch_companies
    companies = Company.includes(:informations, :employees => [:pointing_flyers]).page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    if params[:sSearch].present?
      companies = companies.where('LOWER(companies.email) LIKE LOWER(:search) OR LOWER(companies.firstname) LIKE LOWER(:search) OR LOWER(companies.lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    companies
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[companies.email companies.firstname companies.lastname companies.lastname companies.lastname companies.lastname companies.disable_at ]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
