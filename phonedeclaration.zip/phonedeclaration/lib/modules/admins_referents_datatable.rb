class AdminsReferentsDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view)
    @view = view
  end

  def as_json(options = {})
    if params[:company_id].present?
      total_records = Referent.joins(:companies).where(companies: {id: params[:company_id]}).distinct.count
    else
      total_records = Referent.count
    end
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: total_records,
      iTotalDisplayRecords: referents.total_entries,
      aaData: data
    }
  end

private

  def data
    referents.map do |referent|
      delete_referent = link_to(raw("<i class='fa fa-trash'></i>"), admins_referent_path(referent.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet utilisateur ?"}, class: "btn btn-icon", id: "delete-referent-#{referent.id}" )
      span_edit = link_to(raw("<i class='fa fa-pencil'></i>"), edit_admins_referent_path(id: referent.id, company_id: params[:company_id]), class: "btn btn-icon", "referentId"=> referent.id, method: :get)
      # span_planning = link_to(raw("<i class='fa fa-calendar'></i>"), admins_referent_path(referent.id), class: "btn btn-icon", "referentId"=> referent.id, method: :get)
      # span_hours_history = link_to(raw("<i class='fa fa-tachometer'></i>"), hours_history_admins_referent_path(referent.id), class: "btn btn-icon", "referentId"=> referent.id, method: :get)
      # span_pointing_flyers = link_to(raw("<i class='fa fa-clock-o'></i>"), pointing_flyers_admins_referent_path(referent.id), class: "btn btn-icon", "referentId"=> referent.id, method: :get)
      [
        referent.lastname,
        referent.firstname,
        referent.email,
        (params[:company_id].present? ? referent.referent_infos.count : referent.referent_infos.length),
        "<div class=''>#{span_edit}#{delete_referent}</div>"
      ]
    end
  end

  def referents
    @referents ||= fetch_referents
  end

  def fetch_referents
    if params[:company_id].present?
      referents = Referent.includes(:companies).references(:companies).where(companies: {id: params[:company_id]}).page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    else
      referents = Referent.includes(:companies).page(page).per_page(per_page).order("#{sort_column} #{sort_direction}")
    end
    if params[:sSearch].present?
      referents = referents.where('LOWER(referents.email) LIKE LOWER(:search) OR LOWER(referents.firstname) LIKE LOWER(:search) OR LOWER(referents.lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    referents
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[referents.lastname referents.firstname referents.email referents.email referents.email]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
