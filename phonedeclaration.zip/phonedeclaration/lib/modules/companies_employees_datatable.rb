class CompaniesEmployeesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view, company, referent = nil)
    @view = view
    @company = company
    @referent = referent
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: @company.informations.count,
      iTotalDisplayRecords: informations.total_entries,
      aaData: data
    }
  end

private

  def data
    informations.map do |information|
      delete_information = @referent.present? ? '' : link_to(raw("<i class='fa fa-trash'></i>"), companies_information_path(information.id), remote: true, method: :delete, data: { confirm: "Voulez-vous supprimer cet employée ?"}, class: "btn btn-icon", id: "delete-information-#{information.id}" )
      span_edit = @referent.present? ? '' : link_to(raw("<i class='fa fa-pencil'></i>"), edit_companies_information_path(information.id), class: "btn btn-icon", "informationId"=> information.id, method: :get)
      span_planning = link_to(raw("<i class='fa fa-calendar'></i>"), companies_information_planning_path(information.id, "employee"), class: "btn btn-icon", method: :get)
      span_pointing_flyers = link_to(raw("<i class='fa fa-clock-o'></i>"), companies_information_pointing_flyers_path(information.id), class: "btn btn-icon", method: :get)
      [
        information.lastname,
        information.firstname,
        information.email,
        "<div class=''>#{span_edit}#{span_planning}#{span_pointing_flyers}#{delete_information}</div>"
      ]
    end
  end

  def informations
    @informations ||= fetch_informations
  end

  def fetch_informations
    informations = @company.informations.joins(:employee).order("#{sort_column} #{sort_direction}")
    informations = informations.page(page).per_page(per_page)
    if params[:sSearch].present?
      informations = informations.where('LOWER(employees.email) LIKE LOWER(:search) OR LOWER(firstname) LIKE LOWER(:search) OR LOWER(lastname) LIKE LOWER(:search) OR LOWER(employees.public_uid) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    informations
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[employees.email firstname firstname ]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
