class EmployeesHoursHistoryDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view, employee)
    @view = view
    @employee = employee
    @total_hours = 0
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalDisplayRecords: hours_history.count,
      iTotalRecords: @total_hours,
      aaData: data
    }
  end

private

  def data
    hours_history.map do |hour_history|
      [
          hour_history[:month_nbr],
          hour_history[:pointing_flyers_nbr],
          hour_history[:hours_nbr]
      ]
    end
  end

  def hours_history
    @hours_history ||= fetch_hours_history
  end

  def fetch_hours_history
    if params[:company_id].present?
      first_mission = PointingFlyer.joins(:meeting).where(employee_id: @employee.id, meetings: {company_id: params[:company_id]}).order(created_at: :asc).first
    else
      first_mission = PointingFlyer.where(employee_id: @employee.id).order(created_at: :asc).first
    end

    current_date = DateTime.current

    hours_history = []

    if first_mission.present?
      start_date = first_mission.created_at
      while start_date < current_date.end_of_month do
        hour_time = 0

        if params[:company_id].present?
          pointing_flyers = PointingFlyer.joins(:meeting).where(created_at: start_date.beginning_of_month..start_date.end_of_month, meetings: {company_id: params[:company_id]})
        else
          pointing_flyers = PointingFlyer.where(created_at: start_date.beginning_of_month..start_date.end_of_month)
        end

        pointing_flyers.map{|p_f| hour_time += p_f.updated_at - p_f.created_at}
        hours_history.push({
                               month_nbr: start_date.strftime("%m/%Y"),
                               pointing_flyers_nbr: pointing_flyers.count,
                               hours_nbr: format_duration_to_time(hour_time)
                           })

        start_date += 1.month
        @total_hours += 1
      end
    end

    hours_history = hours_history.sort_by { |hour_history| hour_history[:month_nbr]  }
    hours_history.reverse! if sort_direction == 'desc'
    hours_history[page..per_page]
  end

  def page
    params[:iDisplayStart].to_i/per_page
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i-1 : 9
  end

  def sort_column
    columns = %w[]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end

  # Get time diff between 2 dates.
  #
  # @see https://stackoverflow.com/a/19596579
  def format_duration_to_time(seconds_diff)

    hours = seconds_diff.to_i / 3600
    seconds_diff -= hours * 3600

    minutes = seconds_diff.to_i / 60
    seconds_diff -= minutes * 60

    seconds = seconds_diff.to_i

    "#{hours.to_s.rjust(2, '0')} heures et #{minutes.to_s.rjust(2, '0')} minutes"
  end
end
