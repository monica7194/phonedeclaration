class EmployeesCompaniesDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  def initialize(view, employee)
    @view = view
    @employee = employee
  end

  def as_json(options = {})
    {
      sEcho: params[:sEcho].to_i,
      iTotalRecords: @employee.companies.count,
      iTotalDisplayRecords: companies.total_entries,
      aaData: data
    }
  end

private

  def data
    companies.map do |company|
      span_planning = link_to(raw("<i class='fa fa-calendar'></i>"), employees_plannings_path(company_id: company.id), class: "btn btn-icon", method: :get)
      span_hours_history = link_to(raw("<i class='fa fa-clock-o'></i>"), employees_hours_history_index_path(company_id: company.id), class: "btn btn-icon", method: :get)
      span_pointing_flyers = link_to(raw("<i class='fa fa-tachometer'></i>"), employees_pointing_flyers_path(company_id: company.id), class: "btn btn-icon", method: :get)
      [
          company.lastname,
          company.firstname,
          company.email,
        "<div class=''>#{span_planning}#{span_hours_history}#{span_pointing_flyers}</div>"
      ]
    end
  end

  def companies
    @companies ||= fetch_companies
  end

  def fetch_companies
    companies = @employee.companies.order("#{sort_column} #{sort_direction}")
    companies = companies.page(page).per_page(per_page)
    if params[:sSearch].present?
      companies = companies.where('LOWER(companies.email) LIKE LOWER(:search) OR LOWER(companies.firstname) LIKE LOWER(:search) OR LOWER(companies.lastname) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    companies
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[lastname firstname email email]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "desc" ? "desc" : "asc"
  end
end
