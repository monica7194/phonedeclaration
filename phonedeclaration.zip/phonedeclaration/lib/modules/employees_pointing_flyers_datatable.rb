class EmployeesPointingFlyersDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  include ApplicationHelper
  def initialize(view, current_employee, current_meeting = nil)
    @view = view
    @current_employee = current_employee
    @current_meeting = current_meeting
  end

  def as_json(options = {})
    if params[:company_id].present?
      pointing_flyers_count = PointingFlyer.joins(:meeting => :planning).where(employee_id: @current_employee.id, meetings: {company_id: params[:company_id], plannings: {employee_id: @current_employee.id}}).count
    else
      pointing_flyers_count = PointingFlyer.joins(:meeting).where(employee_id: @current_employee.id).count
    end
    {
        sEcho: params[:sEcho].to_i,
        iTotalRecords: pointing_flyers_count,
        iTotalDisplayRecords: pointing_flyers.total_entries,
        aaData: data
    }
  end

  private

  def data
    pointing_flyers.map do |pointing_flyer|
      [
          pointing_flyer.meeting.title,
          pointing_flyer.created_at.strftime("%d/%m/%Y %H:%M:%S"),
          pointing_flyer.updated_at.strftime("%d/%m/%Y %H:%M:%S"),
          ((pointing_flyer.late? ? "<div class='text-danger'>#{second_diff(pointing_flyer.late_time_abs)}</div>" : '') rescue nil ),
          ((pointing_flyer.over_work? ? "<div class=\"text-danger\">" + second_diff(pointing_flyer.over_work_time_abs) + "</div>" : '') rescue nil),
          pointing_flyer.job_in_progress ? time_diff(Time.now, pointing_flyer.created_at) : time_diff(pointing_flyer.updated_at, pointing_flyer.created_at),
          time_diff(pointing_flyer.updated_at, pointing_flyer.created_at)
      ]
    end
  end

  def pointing_flyers
    @pointing_flyers ||= fetch_pointing_flyers
  end

  def fetch_pointing_flyers
    if params[:company_id].present?
      pointing_flyers = PointingFlyer.includes(:meeting, :employee => [:informations]).joins(:meeting => :planning).where(employee_id: @current_employee.id, meetings: {company_id: params[:company_id], plannings: {employee_id: @current_employee.id}}).order("#{sort_column} #{sort_direction}")
    else
      pointing_flyers = PointingFlyer.includes(:meeting, :employee => [:informations]).joins(:meeting).where(employee_id: @current_employee.id).order("#{sort_column} #{sort_direction}")
    end
    pointing_flyers = pointing_flyers.page(page).per_page(per_page)
    if params[:sSearch].present?
      pointing_flyers = pointing_flyers.where('LOWER(meetings.title) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    pointing_flyers
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[meetings.title pointing_flyers.created_at pointing_flyers.updated_at]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "asc" ? "asc" : "desc"
  end
end
