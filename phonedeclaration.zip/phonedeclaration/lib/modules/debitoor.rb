module Debitoor
  attr_accessor :access_token
  @access_token = ENV['debitoor_access_token']
  @account_name = "MVP Phone Application"
  def self.get_country
    uri = URI.parse("https://api.debitoor.com/api/countries/v1?token=#{@access_token}")
    response = HTTParty.get(uri)
    response.parsed_response
  end

  def self.validate_invoice lines, customer_id
    response = HTTParty.post "https://api.debitoor.com/api/sales/draftinvoices/validate/v3?token=#{@access_token}",
      headers: { "Accept" => "application/json" },
      body: { "lines" => [lines], "customerId" => customer_id, "paymentTermsId" => 1 }.to_json
    response.parsed_response
  end
  def self.add_draft_invoice lines, customer_id
    response = HTTParty.post "https://api.debitoor.com/api/sales/draftinvoices/v3?token=#{@access_token}",
      body: {"lines" => [lines],"customerId" => customer_id, "paymentTermsId" => 1}.to_json
    if response.parsed_response["errors"].present?
      parsed_response =  response.parsed_response
      parsed_response["id"] = nil
      parsed_response
    else
      response.parsed_response
    end
  end
  def self.add_client name, email, address="", phone="", vatNumber=""
    response = HTTParty.post "https://api.debitoor.com/api/customers/v1?token=#{@access_token}",headers:{ "Content-Type" => "application/json" },
      body: {"name" => name, "email" => email,"paymentTermsId" => 1, countryCode: "FR", address: address, phone: phone, vatNumber: vatNumber}.to_json
    if response.parsed_response["errors"].present?
      p response.parsed_response
      response.parsed_response["id"] = nil
    end
    response.parsed_response
  end
  def self.clients
    uri = URI.parse("https://api.debitoor.com/api/customers/v1?token=#{@access_token}")
    response = HTTParty.get(uri, :headers => {'Content-Type' => 'application/json', 'Accept' => 'application/json', token: @access_token})
    if response.parsed_response["errors"].present?
      response.parsed_response["id"] = nil
    end
    response.parsed_response
  end
  def self.send_email id,recipient, subject
    response = HTTParty.post "https://api.debitoor.com/api/sales/invoices/#{id}/email/v2?token=#{@access_token}",
      headers:{ "Accept" => "application/json" },
      body: {"recipient" => recipient, "subject" => subject, "message" => "Voici votre facture"}.to_json
    puts response.parsed_response["id"]
    response.parsed_response # Unparsed body

  end
  def self.get_pdf_invoice id
    response = HTTParty.get "https://api.debitoor.com/api/sales/invoices/#{id}/pdf/v1?token=#{@access_token}",
      headers:{ "Accept" => "application/json" }
    puts response.parsed_response["id"]
    response.parsed_response # Unparsed body

  end
  def self.draft_to_impay id
    response = HTTParty.post "https://api.debitoor.com/api/sales/draftinvoices/#{id}/book/v3?token=#{@access_token}",
      headers:{ "Accept" => "application/json" }
    response.parsed_response # Unparsed body
  end
  def self.create_payment_account account_name = @account_name
    response = HTTParty.get "https://api.debitoor.com/api/paymentaccounts/v1?token=#{@access_token}"
    account_list = response.parsed_response
    account = account_list.select{|a| a["accountName"] == account_name}.first
    if account.present?
      admin_info_edit_debitoor_account account["id"], account_name
    else
      response = HTTParty.post "https://api.debitoor.com/api/paymentaccounts/v1?token=#{@access_token}",
        headers:{ "Accept" => "application/json" },
        body: {'accountName' => account_name, 'amountDelta' => 0, 'currency' => 'EUR','integrationType' => 'manual','paymentType' => 'bank'}.to_json
      admin_info_edit_debitoor_account response.parsed_response["id"], account_name
    end
  end
  def self.create_payment amount, invoice_id, account_name = @account_name
    admin_info=  AdminInfo.find_by(debitoor_payment_account_name: "#{account_name}")
    response = HTTParty.post "https://api.debitoor.com/api/paymentaccounts/payments/v1?token=#{@access_token}",
      headers:{ "Accept" => "application/json" },
      body: {"paymentAccountId" => admin_info.debitoor_payment_account_id, "amount" => amount,"currency" => "EUR","invoiceId" => invoice_id }.to_json
    puts response.parsed_response
  end

  def self.create_and_send_invoice lines, client_id, email, total, account_name = @account_name
    create_payment_account account_name
    invoice = add_draft_invoice lines, client_id
    p invoice
    p draft_to_impay invoice["id"]
    p create_payment total, invoice["id"], account_name
    send_email invoice["id"], email, "Facture #{account_name}"
    invoice
  end
  private
  def self.admin_info_edit_debitoor_account id, account_name = @account_name
    admin_info = AdminInfo.first_or_initialize(debitoor_payment_account_id: id)
    if admin_info.debitoor_payment_account_id.blank?
      admin_info.update_attributes!(debitoor_payment_account_name: account_name,debitoor_payment_account_id: id)
    else
      admin_info.update_attributes!(debitoor_payment_account_name: account_name) if admin_info.debitoor_payment_account_name.blank?
    end
  end
end
