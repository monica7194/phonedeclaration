class CompaniesAllPointingFlyersDatatable
  delegate :params, :h, :link_to, :number_to_currency, to: :@view
  include Rails.application.routes.url_helpers # for path
  include ActionView::Helpers::OutputSafetyHelper #for raw
  include ApplicationHelper
  def initialize(view, company)
    @view = view
    @company = company
  end

  def as_json(options = {})
    {
        sEcho: params[:sEcho].to_i,
        iTotalRecords: pointing_flyers.count,
        iTotalDisplayRecords: pointing_flyers.total_entries,
        aaData: data
    }
  end

  private

  def data
    pointing_flyers.map do |pointing_flyer|
      # delay_margin = pointing_flyer.employee.informations[0].delay_margin.present? ? pointing_flyer.employee.informations[0].delay_margin.minute : 5.minute
      [
          pointing_flyer.meeting.title,
          link_to(raw(pointing_flyer.employee.informations[0].firstname + ' ' + pointing_flyer.employee.informations[0].lastname), companies_information_pointing_flyers_path(pointing_flyer.employee.informations[0].id), class: "btn btn-link", method: :get),
          # pointing_flyer.meeting.start_date.strftime("%d/%m/%Y %H:%M:%S"),
          # pointing_flyer.meeting.end_date.strftime("%d/%m/%Y %H:%M:%S"),
          pointing_flyer.created_at.strftime("%d/%m/%Y %H:%M:%S"),
          pointing_flyer.updated_at.strftime("%d/%m/%Y %H:%M:%S"),
          ((pointing_flyer.late? ? "<div class='text-danger'>#{second_diff(pointing_flyer.late_time_abs)}</div>" : '') rescue nil ),
          ((pointing_flyer.over_work? ? "<div class=\"text-danger\">" + second_diff(pointing_flyer.over_work_time_abs) + "</div>" : '') rescue nil),
          pointing_flyer.job_in_progress ? time_diff(Time.now, pointing_flyer.created_at) : time_diff(pointing_flyer.updated_at, pointing_flyer.created_at),
          pointing_flyer.job_in_progress ? 'En cours' : 'Terminée'
      ]
    end
  end

  def pointing_flyers
    @pointing_flyers ||= fetch_pointing_flyers
  end

  def fetch_pointing_flyers
    if params[:range_start].present? && params[:range_end].present?
      pointing_flyers = PointingFlyer
                             .includes(:meeting)
                             .includes(employee: :informations)
                             .references(:meeting)
                             .references(employee: :informations)
                             .where(employee: {information: {company_id: @company.id}}, meetings: {company_id: @company.id})
                             .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                             .order("#{sort_column} #{sort_direction}")
    else
      pointing_flyers = PointingFlyer
                             .includes(:meeting)
                             .includes(employee: :informations)
                             .references(:meeting)
                             .references(employee: :informations)
                             .where(employee: {information: {company_id: @company.id}}, meetings: {company_id: @company.id})
                             .order("#{sort_column} #{sort_direction}")
    end
    pointing_flyers = pointing_flyers.page(page).per_page(per_page)
    if params[:sSearch].present?
      pointing_flyers = pointing_flyers.where('LOWER(meetings.title) LIKE LOWER(:search)', search: "%#{params[:sSearch]}%")
    end
    pointing_flyers
  end

  def page
    params[:iDisplayStart].to_i/per_page + 1
  end

  def per_page
    params[:iDisplayLength].to_i > 0 ? params[:iDisplayLength].to_i : 10
  end

  def sort_column
    columns = %w[meetings.title information.firstname pointing_flyers.created_at pointing_flyers.updated_at pointing_flyers.job_in_progress pointing_flyers.job_in_progress pointing_flyers.job_in_progress]
    columns[params[:iSortCol_0].to_i]
  end

  def sort_direction
    params[:sSortDir_0] == "asc" ? "asc" : "desc"
  end
end
