# frozen_string_literal: true

class CompaniesRegistration::RegistrationsController < Devise::RegistrationsController
  before_action :configure_sign_up_params, only: [:create]
  before_action :configure_account_update_params, only: [:update]
  before_action :company_card_redirect, only: [:edit, :update]
  layout :custom_layout
  # GET /resource/sign_up
  # def new
  #   super
  # end

  # POST /resource
  # def create
  #   super
  # end

  # GET /resource/edit
  # def edit
  #   super
  # end

  # PUT /resource
  # def update
  #   super
  # end

  # DELETE /resource
  # def destroy
  #   super
  # end

  # GET /resource/cancel
  # Forces the session data which is usually expired after sign
  # in to be expired now. This is useful if the user wants to
  # cancel oauth signing in/up in the middle of the process,
  # removing all OAuth session data.
  # def cancel
  #   super
  # end
  #

  def disabled
    current_company.disabled
    if current_company.disabled?
      Meeting.where(company_id: current_company.id).where("start_date >= ?", current_company.disabled_at).delete_all
    end
    flash[:notice] = "Votre compte est  #{current_company.disabled? ? "désactivé" : "activé"} #{". La désactivation sera effective le " + current_company.disabled_at.strftime('%d/%m/%Y') if current_company.disabled?}"
    redirect_back fallback_location: root_path
  end

  protected

  # If you have extra params to permit, append them to the sanitizer.
  def configure_sign_up_params
    devise_parameter_sanitizer.permit(:sign_up, keys: [:firstname, :lastname, :birthdate, :birthplace, :exonerations, :address_1, :address_2, :city, :postal_code, :country, :phone_number, :gsm_number, :rgpd_agreement, :cgv_agreement, :nationality, :social_security_number])
  end

  # If you have extra params to permit, append them to the sanitizer.
  def configure_account_update_params
    devise_parameter_sanitizer.permit(:account_update, keys: [:firstname, :lastname, :birthdate, :birthplace, :exonerations, :address_1, :address_2, :city, :postal_code, :country, :phone_number, :gsm_number, :nationality, :social_security_number])
  end

  def update_resource(resource, params)
    resource.update_without_password(params)
  end

  # The path used after sign up.
  # def after_sign_up_path_for(resource)
  #   super(resource)
  # end

  # The path used after sign up for inactive accounts.
  # def after_inactive_sign_up_path_for(resource)
  #   super(resource)
  # end

  def custom_layout
    case action_name
    when "edit", "update"
      "companies"
    else
      "application"
    end
  end
  def company_card_redirect
    if current_company.present? && current_referent.blank? && current_company.stripe_card_id.blank? &&current_company.gocardless_bank_id.blank?
    #if current_company.present? && current_referent.blank? && current_company.stripe_card_id.blank?
     redirect_to edit_companies_billing_path(current_company.id)
    end
  end
end
