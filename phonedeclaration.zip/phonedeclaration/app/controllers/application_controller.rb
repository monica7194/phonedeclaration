class ApplicationController < ActionController::Base
  protect_from_forgery with: :exception

  private
  # Get time diff between 2 dates.
  #
  # @see https://stackoverflow.com/a/19596579
  def format_duration_to_time(seconds_diff)

    hours = seconds_diff.to_i / 3600
    seconds_diff -= hours * 3600

    minutes = seconds_diff.to_i / 60
    seconds_diff -= minutes * 60

    seconds = seconds_diff.to_i

    "#{hours.to_s.rjust(2, '0')} heures et #{minutes.to_s.rjust(2, '0')} minutes"
  end

  def get_company_from_session
    if current_referent.present? && referent_session["company_id"].present?
      if @current_company.blank?
        @current_company = Company.find(referent_session["company_id"])
      else
        @current_company
      end
    elsif current_company.present?
      @current_company = current_company
    else
      @current_company = nil
    end
  end

  def get_stats(information_id, company_id = nil, is_employee = false)
    dateMonth = DateTime.current.month
    case dateMonth
    when 1
    when 2
    when 3
      start_date = DateTime.new(DateTime.current.year, 1, 1)
      end_date = DateTime.new(DateTime.current.year, 3, 31)
    when 4
    when 5
    when 6
      start_date = DateTime.new(DateTime.current.year, 4, 1)
      end_date = DateTime.new(DateTime.current.year, 6, 31)
    when 7
    when 8
    when 9
      start_date = DateTime.new(DateTime.current.year, 7, 1)
      end_date = DateTime.new(DateTime.current.year, 9, 31)
    else
      start_date = DateTime.new(DateTime.current.year, 10, 1)
      end_date = DateTime.new(DateTime.current.year, 12, 31)
    end
    dates = [
      [DateTime.current.beginning_of_day, DateTime.current.end_of_day],
      [DateTime.current.beginning_of_week, DateTime.current.end_of_week],
      [DateTime.current.beginning_of_month, DateTime.current.end_of_month],
      [DateTime.current.prev_month.beginning_of_month, DateTime.current.prev_month.end_of_month],
      [DateTime.current.beginning_of_quarter, DateTime.current.end_of_quarter],
      [start_date, end_date],
      [DateTime.current.beginning_of_year, DateTime.current.end_of_year],
      [DateTime.current.prev_year.beginning_of_year, DateTime.current.prev_year.end_of_year]
    ]
    times = {day: 0, week: 0, month: 0, prev_month: 0, quarter: 0, semestre: 0, year: 0, prev_year: 0}
    dates.each_with_index do |date, index|
      if is_employee
        day_pointing_flyers = PointingFlyer
                                  .joins(employee: :informations).includes(employee: :informations).includes(:meeting)
                                  .where(employee_id: information_id)
                                  .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: date[0], end_date: date[1])
                                  .order(updated_at: :desc)

      elsif company_id.present?
        day_pointing_flyers = PointingFlyer
                                  .joins(employee: :informations).includes(employee: :informations).includes(meeting: [:company])
                                  .where(employee: {information: {id: information_id}})
                                  .where(companies: {id: company_id})
                                  .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: date[0], end_date: date[1])
                                  .order(updated_at: :desc)
      else
        day_pointing_flyers = PointingFlyer
                                  .joins(employee: :informations).includes(employee: :informations).includes(:meeting)
                                  .where(employee: {information: {id: information_id}})
                                  .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: date[0], end_date: date[1])
                                  .order(updated_at: :desc)

      end


      key = times.keys[index]
      times[key] = 0
      day_pointing_flyers.map do |pointing_flyer|
        times[key] += pointing_flyer.updated_at - pointing_flyer.created_at
      end

    end
    {
        day_time: format_duration_to_time(times[:day]),
        week_time: format_duration_to_time(times[:week]),
        month_time: format_duration_to_time(times[:month]),
        prev_month_time: format_duration_to_time(times[:prev_month]),
        quarter_time: format_duration_to_time(times[:quarter]),
        semester_time: format_duration_to_time(times[:semestre]),
        year_time: format_duration_to_time(times[:year]),
        lastyear_time: format_duration_to_time(times[:prev_year])
    }
  end

  def after_sign_in_path_for(resource)
    request.env['omniauth.origin'] || stored_location_for(resource) || root_url
  end
end
