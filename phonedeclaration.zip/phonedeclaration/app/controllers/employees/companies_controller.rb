class Employees::CompaniesController < ApplicationController
  layout "employees"
  before_action :authenticate_employee!
  
  def index
    respond_to do |format|
      format.html
      format.json { render json: EmployeesCompaniesDatatable.new(view_context, current_employee) }
    end
  end
end
