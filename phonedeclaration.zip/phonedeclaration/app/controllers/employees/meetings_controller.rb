class Employees::MeetingsController < EmployeesController
  before_action :set_planning, except: [:accepted, :refused]
  skip_before_action :authenticate_employee_or_admin!, only: [:accepted, :refused]
  def create
    @meeting = Meeting.new meeting_params.merge!({planning: @planning})
    if @meeting.valid?
      @planning.meetings << @meeting
      @meetings.to_a << @meeting
    else
      render js: "toastr['error']('#{ @meeting.errors.full_messages.join(', ')}')"
    end
  end
  def update
    @meeting = Meeting.find params[:id]
    if @meeting.company.blank?
      unless @meeting.update meeting_params
        render js: "toastr['error']('#{ @meeting.errors.full_messages.join(', ')}')"
      end
    else
      render js: "toastr['error']('Vous ne pouvez pas modifier ce meeting')"
    end
  end

  def destroy
    @meeting = Meeting.find_by(id: params[:id])
    if @meeting.present?
      @meeting.destroy
      if @meeting.destroyed?
        flash.now[:notice] = "Le rendez vous a été supprimé"
      else
        flash.now[:notice] = "Il y a eu un problème lors de la suppression"
      end
    end
  end
  def accepted
    if current_employee.present?
      if params[:token].present?
        @meeting = Meeting.find_by(id: params[:id], token: params[:token])
        if @meeting.present?
          if @meeting.token_expired_date.blank?
            @meeting.update_state_by_email Meeting::STATES[:accepted], true
            flash[:notice] = "La mission a été acceptée"
          else
            if @meeting.token_used_date.present?
              flash[:notice] = "La mission a déjà été #{@meeting.state == 1 ? "Refusée" : "Acceptée" }"
            else
              flash[:notice] = "Le délai pour accepter la mission est dépassé la mission a été refuser"
            end
          end
        else
          flash[:notice] = "La mission n'a pas été trouvée"
        end
      end
    else
      authenticate_employee!
    end
    redirect_to employees_plannings_path
  end
  def refused
    if current_employee.present?
      if params[:token].present?
        @meeting = Meeting.find_by(id: params[:id], token: params[:token])
        if @meeting.present?
          if @meeting.token_expired_date.blank?
            @meeting.update_state_by_email Meeting::STATES[:refused], true
            flash[:notice] = "La mission a été refusée"
          else
            if @meeting.token_used_date.present?
              flash[:notice] = "La mission a déjà été #{@meeting.state == 1 ? "Refusée" : "Acceptée" }"
            else
              flash[:notice] = "Le délai pour accepter la mission est dépassé la mission a été refuser"
            end
          end
        else
          flash[:notice] = "La mission n'a pas été trouvée"
        end
      end
    else
      authenticate_employee!
    end
    redirect_to employees_plannings_path
  end
  def sick_leave
    current_employee = Employee.find params[:employee_id]
    start_date = Time.current + 1.hour + 1.minute
    end_date = start_date > Time.current.noon ? Time.current.midnight + 1.day : Time.current.noon
    @meeting = Meeting.create planning: @planning, title: "Arret maladie", start_date: start_date, end_date: end_date, company_id: nil, day_off_reason: Meeting::DAY_OFF_REASON[:sick_leave]
    if @meeting.valid?
      flash[:notice] = "L'arret maladie a été créer'"
    else
      flash[:notice] = @meeting.errors.full_messages.join(', ')
    end
    redirect_back fallback_location: root_path
  end
  private
  def meeting_params
    params[:meeting][:start_date] = Time.zone.parse(params[:meeting][:start_date])
    if params[:meeting][:end_date].present?
      params[:meeting][:end_date] = Time.zone.parse(params[:meeting][:end_date])
    end
    if params[:meeting][:company_id] == Meeting::DAY_OFF_REASON[:sick_leave].to_s
      params[:meeting][:day_off_reason] = Meeting::DAY_OFF_REASON[:sick_leave]
      params[:meeting][:company_id] = nil
    elsif params[:meeting][:company_id].blank? || params[:meeting][:company_id] == Meeting::DAY_OFF_REASON[:day_off].to_s
      params[:meeting][:day_off_reason] = Meeting::DAY_OFF_REASON[:day_off]
      params[:meeting][:company_id] = nil
    end
    params.require(:meeting).permit(:title, :start_date, :end_date, :company_id, :day_off_reason)
  end
end
