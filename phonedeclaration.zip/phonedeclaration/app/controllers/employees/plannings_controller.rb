class Employees::PlanningsController < EmployeesController
  before_action :set_planning
  def index
    if @company_id.present?
      @options_for_company_select = current_employee.companies.where(id: @company_id).pluck("concat(companies.firstname, ' ', 'companies.lastname')", :id)
      # @options_for_company_select = current_employee.companies.where(id: @company_id).pluck("concat(email, ' ', email)", :id)
      @meetings = @planning.meetings.where(company_id: @company_id).or(@planning.meetings.where(company_id: nil))
    else
      @options_for_company_select = current_employee.companies.pluck("concat(companies.firstname, ' ', companies.lastname)", :id)
      # @options_for_company_select = current_employee.companies.pluck("concat(email, ' ', email)", :id)
      @meetings = @planning.meetings
    end
    @options_for_company_select.unshift ["Arret maladie", Meeting::DAY_OFF_REASON[:sick_leave]]
    @options_for_company_select.unshift ["Jour de congé", Meeting::DAY_OFF_REASON[:day_off]]

  end
end
