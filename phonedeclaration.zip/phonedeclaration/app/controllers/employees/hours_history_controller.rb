class Employees::HoursHistoryController < EmployeesController
  layout "employees"

  def index
    @current_employee = Employee.find(params[:employee_id]) if current_admin.present?
    respond_to do |format|
      format.html
      format.json { render json: EmployeesHoursHistoryDatatable.new(view_context, current_employee) }
    end
  end
end
