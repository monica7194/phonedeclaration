class Employees::PointingFlyersController < EmployeesController
  layout "employees"
  before_action :set_pointing_flyer, only: [:show, :edit, :update, :destroy]

  # GET /pointing_flyers
  # GET /pointing_flyers.json
  def index
    @current_employee = Employee.find(params[:employee_id]) if current_admin.present?
    @pointing_flyers = PointingFlyer.where(employee_id: current_employee.id).order(updated_at: :desc)
    @current_meeting = Meeting.current_mission(current_employee.id).first
    next_mission = Meeting.next_mission(DateTime.current, current_employee.id).first

    if @current_meeting.present? && @current_meeting != next_mission
      @next_meeting = next_mission
    else
      @current_meeting = next_mission
      @next_meeting = nil
    end
    @current_pointing_flyer = PointingFlyer.find_by(meeting_id: @current_meeting.id, job_in_progress: true) if @current_meeting.present?
    @stats = get_stats(current_employee.id, nil, true)

    respond_to do |format|
      format.html
      format.json { render json: EmployeesPointingFlyersDatatable.new(view_context, current_employee, @current_meeting) }
      format.pdf do
        render pdf: "pointing_flyers",
          encoding: "UTF-8",
          margin: {left: 0, right: 0, bottom: 0, top: 0},
          layout: 'pdf.html',
          disposition: 'attachment'
      end
    end
  end

  # GET /pointing_flyers/1
  # GET /pointing_flyers/1.json
  def show
  end

  # GET /pointing_flyers/new
  def new
    @pointing_flyer = PointingFlyer.new
  end

  # GET /pointing_flyers/1/edit
  def edit
  end

  # POST /pointing_flyers
  # POST /pointing_flyers.json
  def create
    @pointing_flyer = PointingFlyer.new(pointing_flyer_params)
    @pointing_flyer.meeting = Meeting.next_mission(DateTime.current, current_employee.id).first
    @pointing_flyer.employee = current_employee
    @pointing_flyer.job_in_progress = true

    respond_to do |format|
      if @pointing_flyer.save
        format.html { redirect_to employees_pointing_flyers_path, notice: I18n.t("pointing_flyer.create_success") }
        format.json { render :show, status: :created, location: @pointing_flyer }
      elsif current_meeting.blank?
        format.html { redirect_to employees_pointing_flyers_path, alert: I18n.t("pointing_flyer.no_curr_meeting") }
      else
        format.html { redirect_to employees_pointing_flyers_path, alert: @pointing_flyer.errors.full_messages.join(", ") }
        format.json { render json: @pointing_flyer.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /pointing_flyers/1
  # PATCH/PUT /pointing_flyers/1.json
  def update

    @pointing_flyer.job_in_progress = false

    respond_to do |format|
      if @pointing_flyer.update(pointing_flyer_params)
        format.html { redirect_to employees_pointing_flyers_path, notice: I18n.t("pointing_flyer.update_success") }
        format.json { render :show, status: :ok, location: @pointing_flyer }
      else
        # raise @pointing_flyer.errors.inspect
        format.html { render :edit }
        format.json { render json: @pointing_flyer.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /pointing_flyers/1
  # DELETE /pointing_flyers/1.json
  def destroy
    @pointing_flyer.destroy
    respond_to do |format|
      format.html { redirect_to pointing_flyers_url, notice: 'Pointing flyer was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
  # Use callbacks to share common setup or constraints between actions.
  def set_pointing_flyer
    @pointing_flyer = PointingFlyer.find(params[:id])
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def pointing_flyer_params
    params.fetch(:pointing_flyer, {})
  end
end
