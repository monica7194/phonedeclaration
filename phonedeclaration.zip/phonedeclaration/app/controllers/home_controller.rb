class HomeController < ApplicationController
  def index
    if current_admin.present?
      redirect_to admins_admins_path
    elsif current_employee.present?
      redirect_to employees_plannings_path
    elsif current_company.present? || current_referent.present?
      redirect_to companies_informations_path
    else
      redirect_to company_session_path
    end
  end

  def svi_company_data
  # Get the last 5 employees of in last meetings.
  # Foreach employee:
  # Get pointing_end.
  # Get pointing_start.
  # Get pointing_hours (day/week/month/last_month).
  # Prompt messages to do online action and transfer to SAV.

    company = Company.public_user_external(params[:login_number]).first

    if company.present?
      last5_employees = Employee.employees_by_meetings_desc(company.id).first(5)

      svi_key = 0
      last5_employees = last5_employees.map do |employee|
        svi_key += 1
        current_meeting = Meeting.current_mission_by_company(employee.id, company.id).first
        started_meeting = Meeting.current_mission_started_by_company(employee.id, company.id).first
        last_meeting = Meeting.last_mission_by_company(employee.id, company.id).last()
        employee.as_json.merge({
          information: employee.informations.where(company_id: company.id).first,
          current_meeting: !current_meeting.present? ? nil : current_meeting.as_json.except!("start_date", "end_date").merge({
             pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
               pointing_flyer.as_json.except!("created_at", "updated_at")
                   .merge({
                              created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                              updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                          })
             end
          }),
          started_meeting: !started_meeting.present? ? nil : started_meeting.as_json.except!("start_date", "end_date").merge({
               pointing_flyers: started_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                 pointing_flyer.as_json.except!("created_at", "updated_at")
                     .merge({
                                created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                                updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                            })
               end
           }),
          last_meeting: !last_meeting.present? ? nil : last_meeting.as_json.except!("start_date", "end_date").merge({
               pointing_flyers: last_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                 pointing_flyer.as_json.except!("created_at", "updated_at")
                     .merge({
                                created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                                updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                            })
               end
           }),
          pointing_hours: get_stats_for_employee(employee.id, company.id),
          svi_key: svi_key
        })
      end

      data = {
          company: company,
          last5_employees: last5_employees
      }
    else
      data = {
          company: nil,
          last5_employees: nil
      }
    end

    respond_to do |format|
      format.json { render json: data }
    end
  end

  def svi_employee_data
    # Pointing start.
    # Pointing end.
    # Day off (sick) for half-day.
    # Day off (vacation) prompt message free online and
    employee = Employee.public_user(params[:phone_number], params[:login_number]).first

    if employee.present?
      company = Company.joins(informations: :employee).where(phone_number: params[:phone_number], employees: {id: employee.id}).first
      current_meeting = Meeting.current_mission_by_company(employee.id, company.id).first
      started_meeting = Meeting.current_mission_started_by_company(employee.id, company.id).first

      data = {
          role: 'READ_WRITE',
          employee: employee.as_json.merge({
               information: employee.informations.joins(:company).where(companies: {phone_number: params[:phone_number]}).first
           }),
          current_meeting: !current_meeting.present? ? nil : current_meeting.as_json.except!("start_date", "end_date").merge({
               pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                 pointing_flyer.as_json.except!("created_at", "updated_at")
                     .merge({
                                created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                                updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                            })
               end
           }),
          started_meeting: !started_meeting.present? ? nil : started_meeting.as_json.except!("start_date", "end_date").merge({
              pointing_flyers: started_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                pointing_flyer.as_json.except!("created_at", "updated_at")
                    .merge({
                         created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                         updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                     })
              end
          })
      }
    else
      employee = Employee.public_user_external(params[:login_number]).first

      if employee.present?
        current_meeting = Meeting.current_mission_by_employee(employee.id).first
        started_meeting = Meeting.current_mission_started_by_employee(employee.id).first

        data = {
            role: 'READ',
            employee: employee.as_json.merge({
                information: employee.informations.first
             }),
            current_meeting: !current_meeting.present? ? nil : current_meeting.as_json.except!("start_date", "end_date").merge({
                 pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                   pointing_flyer.as_json.except!("created_at", "updated_at")
                       .merge({
                                  created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                                  updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                              })
                 end
             }),
            started_meeting: !started_meeting.present? ? nil : started_meeting.as_json.except!("start_date", "end_date").merge({
                 pointing_flyers: started_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                   pointing_flyer.as_json.except!("created_at", "updated_at")
                       .merge({
                                  created_at: pointing_flyer.created_at.strftime("%H heures %M"),
                                  updated_at: pointing_flyer.updated_at.strftime("%H heures %M"),
                              })
                 end
             })
        }
      else
        data = {
            employee: nil,
            current_meeting: nil,
            started_meeting: nil
        }
      end
    end

    respond_to do |format|
      format.json { render json: data }
    end
  end

  def svi_sick_dayoff
    employee = Employee.public_user(params[:phone_number], params[:login_number]).first

    if !employee.present?
      employee = Employee.public_user_external(params[:login_number]).first
    end

    if employee.present?
      start_date = Time.current + 1.minute
      end_date = start_date > Time.current.noon ? Time.current.midnight + 1.day : Time.current.noon
      meeting = Meeting.create planning: employee.planning, title: "Arret maladie", start_date: start_date, end_date: end_date, company_id: nil, day_off_reason: Meeting::DAY_OFF_REASON[:sick_leave]

      if meeting.valid?
        data = {code: "OK", meeting: meeting.as_json.except!("start_date", "end_date")
                                         .merge({
                                                    start_date: meeting.start_date.strftime("%H heures %M"),
                                                    end_date: meeting.end_date.strftime("%H heures %M"),
                                                })}
      else
        data = {code: "ERROR"}
      end

      respond_to do |format|
        format.json { render json: data }
      end
    end
  end

  def svi_vacation_dayoff
    employee = Employee.public_user(params[:phone_number], params[:login_number]).first

    if !employee.present?
      employee = Employee.public_user_external(params[:login_number]).first
    end

    if employee.present?
      start_date = Time.current + 1.minute
      end_date = start_date > Time.current.noon ? Time.current.midnight + 1.day : Time.current.noon
      meeting = Meeting.create planning: employee.planning, title: "Congé", start_date: start_date, end_date: end_date, company_id: nil, day_off_reason: Meeting::DAY_OFF_REASON[:day_off]

      if meeting.valid?
        data = {code: "OK", meeting: meeting.as_json.except!("start_date", "end_date")
           .merge({
                      start_date: meeting.start_date.strftime("%H heures %M"),
                      end_date: meeting.end_date.strftime("%H heures %M"),
                  })}
      else
        data = {code: "ERROR"}
      end

      respond_to do |format|
        format.json { render json: data }
      end
    end
  end

  def cgv
    send_file("#{Rails.root}/public/CGUV.pdf", :filename => "CGUV.pdf", :disposition => 'inline', :type => "application/pdf")
  end

  def svi_employee_login_number
    # 1) Get the employee by company phone_number and public_uid, set role to READ_AND_WRITE.
    # 2) Check if employee else get the employee by employee phone_number and public_uid, set role to READ_ONLY.
    # 3) If READ_AND_WRITE, get company from employee, get total hours for the current month, get total hours for the current company, get the current meeting.

    user = Employee
      .includes(:informations)
      .public_user(params[:phone_number], params[:login_number])
      .where(informations: {companies: {phone_number: params[:phone_number] }})
      .first

    if user.present?
      data = {
        role: 'READ_AND_WRITE',
        user: user.as_json.merge!({
            informations: user.informations
        }),
        company: user.informations[0].company,
        current_meeting: Meeting.current_mission(user.id).first,
        current_pointing: PointingFlyer.find_by(employee_id: user.id, job_in_progress: true),
        hours_of_month: monthly_hours(user.id),
        company_hours_of_month: company_monthly_hours(user.id, user.informations[0].company.id),
        last5_hours_of_month: last5_hours_of_month(user.id)
      }
    else
      user = Employee
        .where(public_uid: params[:login_number])
        .first

      if user.present?
        data = {
            role: 'READ_ONLY',
            user: user.as_json.merge!({
                                          informations: user.informations
                                      }),
            hours_of_month: monthly_hours(user.id),
            last5_hours_of_month: last5_hours_of_month(user.id)
        }
      else
        data = nil
      end
    end

    respond_to do |format|
      format.json { render json: data }
    end
  end

  def svi_company_login_number
    # 1) Get the employee by company phone_number and public_uid, set role to READ_AND_WRITE.
    # 2) Check if employee else get the employee by employee phone_number and public_uid, set role to READ_ONLY.
    # 3) If READ_AND_WRITE, get company from employee, get total hours for the current month, get total hours for the current company, get the current meeting.

    company = Company
      .where(public_uid: params[:login_number], companies: {phone_number: params[:phone_number]})
      .first

    if company.present?
      current_meeting = get_current_meeting(company)
      data = {
          role: 'READ_AND_WRITE',
          company: company,
          current_meeting: current_meeting.blank? ? nil : current_meeting.as_json.except!("start_date", "end_date")
                                                .merge({
                                                           start_date: current_meeting.start_date.strftime("%d/%m/%Y à %H heures %M"),
                                                           end_date: current_meeting.end_date.strftime("%d/%m/%Y à %H heures %M"),
                                                           employee: current_meeting.planning.employee.as_json.merge({
                                                                                                                         informations: current_meeting.planning.employee.informations.where(company_id: company.id)
                                                                                                                     }),
                                                           pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                                                             pointing_flyer.as_json.except!("created_at", "updated_at")
                                                                 .merge({
                                                                            created_at: pointing_flyer.created_at.strftime("%d/%m/%Y à %H heures %M"),
                                                                            updated_at: pointing_flyer.updated_at.strftime("%d/%m/%Y à %H heures %M"),
                                                                        })
                                                           end
                                                       })
      }
    else
      company = Company.where(public_uid: params[:login_number]).first

      if company.present?
        current_meeting = get_current_meeting(company)
        data = {
            role: 'READ_ONLY',
            company: company,
            current_meeting: current_meeting.blank? ? nil : current_meeting.as_json.except!("start_date", "end_date")
                                 .merge({
                                            start_date: current_meeting.start_date.strftime("%d/%m/%Y à %H heures %M"),
                                            end_date: current_meeting.end_date.strftime("%d/%m/%Y à %H heures %M"),
                                            employee: current_meeting.planning.employee.as_json.merge({
                                                                                                          informations: current_meeting.planning.employee.informations.where(company_id: company.id)
                                                                                                      }),
                                            pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
                                              pointing_flyer.as_json.except!("created_at", "updated_at")
                                                  .merge({
                                                             created_at: pointing_flyer.created_at.strftime("%d/%m/%Y à %H heures %M"),
                                                             updated_at: pointing_flyer.updated_at.strftime("%d/%m/%Y à %H heures %M"),
                                                         })
                                            end
                                        }),
            last5_employees_hours_of_month: last5_employees_hours_of_month(company.id),
            last3_employees_hours: last3_employees_hours(company.id)
        }
      else
        data = nil
      end
    end

    respond_to do |format|
      format.json { render json: data }
    end
  end

  def employee_phone_number
    @userByPhoneNumber = Employee.where(phone_number: params[:phone_number]).first

    respond_to do |format|
      format.json { render json: @userByPhoneNumber }
    end
  end

  def employee_login_number
    @userByLoginNumber = Employee.public_user(params[:phone_number], params[:login_number]).first

    respond_to do |format|
      format.json { render json: @userByLoginNumber.present? ? @userByLoginNumber.to_json(include:[:informations]) : 'null' }
    end
  end

  def company_login_number
    @userByLoginNumber = Company.public_user(params[:phone_number], params[:login_number]).first

    respond_to do |format|
      format.json { render json: @userByLoginNumber.present? ? @userByLoginNumber.to_json : nil }
    end
  end

  def employee_current_meeting
    userByLoginNumber = Employee.public_user(params[:phone_number], params[:login_number]).first
    @current_meeting = Meeting.current_mission(userByLoginNumber.id).first
    next_mission = Meeting.next_mission(DateTime.current, userByLoginNumber.id).first

    if @current_meeting.present? && @current_meeting != next_mission
      @next_meeting = next_mission
    else
      @current_meeting = next_mission
      @next_meeting = nil
    end

    @current_pointing_flyer = PointingFlyer.find_by(meeting_id: @current_meeting.id, job_in_progress: true) if @current_meeting.present?

    respond_to do |format|
      format.json do  render json: {
          current_meeting: @current_meeting.present? ? @current_meeting : 'null',
          next_meeting: @next_meeting.present? ? @next_meeting : 'null',
          current_pointing_flyer: @current_pointing_flyer.present? ? @current_pointing_flyer : 'null'
      }
      end
    end
  end

  def employee_pointing_flyer
    # Get the current employee.
    @userByLoginNumber = Employee.public_user(params[:phone_number], params[:login_number]).first
    # Get the current meeting.
    @current_meeting = Meeting.current_mission(@userByLoginNumber.id).first
    # Get the next meeting.
    next_mission = Meeting.next_mission(DateTime.current, @userByLoginNumber.id).first

    if @current_meeting.present? && @current_meeting != next_mission
      @next_meeting = next_mission
    else
      @current_meeting = next_mission
      @next_meeting = nil
    end

    if @current_meeting.present? && @current_meeting.company.phone_number == params[:phone_number]
      if @pointing_flyer.present?
        @pointing_flyer = PointingFlyer.find_by(meeting_id: @current_meeting.id, job_in_progress: true)
        @pointing_flyer.job_in_progress = false
      else
        @old_pointing_flyer = PointingFlyer.find_by(employee_id: @userByLoginNumber.id, job_in_progress: true)
        if @old_pointing_flyer.present?
          @old_pointing_flyer.update(job_in_progress: false)
        end
        @pointing_flyer = PointingFlyer.new()
        @pointing_flyer.job_in_progress = true
        @pointing_flyer.meeting = Meeting.next_mission(DateTime.current, @userByLoginNumber.id).first
        @pointing_flyer.employee = @userByLoginNumber
      end
    end

    respond_to do |format|
      if @pointing_flyer.save
        format.json { render json: @pointing_flyer, status: :created, location: params[:phone_number] }
      elsif @current_meeting.blank?
        format.json { render json: nil, status: :ok }
      else
        format.json { render json: @pointing_flyer.errors, status: :unprocessable_entity }
      end
    end
  end

  # Display last 5 past PointingFlyers.
  def company_employee_pointing_last5
    company = Company.public_user(params[:phone_number], params[:company_login_number]).first
    employee = Employee.public_user(params[:phone_number], params[:employee_login_number]).first
    @pointing = PointingFlyer
                     .joins(meeting: :company)
                     .joins(:employee)
                     .where(meetings: {companies: {id: company.id}}, employees: {id: employee.id}, job_in_progress: false)
                     .order(:updated_at)
                     .last(5)

    respond_to do |format|
      format.json { render json: @pointing.map(&:serializeSVI).to_json }
    end
  end

  # Display last past PointingFlyers.
  def company_employee_pointing_last
    company = Company.public_user(params[:phone_number], params[:company_login_number]).first
    employee = Employee.public_user(params[:phone_number], params[:employee_login_number]).first
    @pointing = PointingFlyer
                     .joins(meeting: :company)
                     .joins(:employee)
                     .where(meetings: {companies: {id: company.id}}, employees: {id: employee.id}, job_in_progress: false)
                     .order(updated_at: :desc)
                     .first

    respond_to do |format|
      format.json { render json: @pointing.present? ? @pointing.serializeSVI.to_json : nil }
    end
  end

  # Display current past PointingFlyers.
  def company_employee_pointing_current
    company = Company.public_user(params[:phone_number], params[:company_login_number]).first
    employee = Employee.public_user(params[:phone_number], params[:employee_login_number]).first
    @pointing = PointingFlyer
                     .joins(meeting: :company)
                     .joins(:employee)
                     .where(meetings: {companies: {id: company.id}}, employees: {id: employee.id}, job_in_progress: true)
                     .order(:updated_at)
                     .first

    respond_to do |format|
      format.json { render json: @pointing.present? ? @pointing.serializeSVI.to_json : nil }
    end
  end

  # Display next past PointingFlyers.
  def company_employee_pointing_next
    company = Company.public_user(params[:phone_number], params[:company_login_number]).first
    employee = Employee.public_user(params[:phone_number], params[:employee_login_number]).first
    @meeting = Meeting.joins(:company).includes(:pointing_flyers).where(pointing_flyers: {id: nil}, companies: {id: company.id}).order(:start_date).first

    respond_to do |format|
      format.json { render json: @meeting.present? ? @meeting.serializeSVI.to_json : nil }
    end
  end

  def employee_pointing_flyer_start
    # Get the logged employee.
    userByLoginNumber = Employee.public_user(params[:phone_number], params[:login_number]).first

    # Get the current meeting.
    current_meeting = Meeting
                          .joins(:planning, :company)
                          .where("companies.phone_number = :phone_number AND start_date <= :currentDateTime AND end_date >= :currentDateTime", {phone_number: params[:phone_number], currentDateTime: DateTime.current})
                          .where("plannings.employee_id = :current_employee_id", {current_employee_id: userByLoginNumber.id})
                          .where(state: 1)
                          .first

    # Get old pointing flyers in progress and stop them.
    old_pointing_flyer = PointingFlyer.find_by(employee_id: userByLoginNumber.id, job_in_progress: true)
    if old_pointing_flyer.present?
      old_pointing_flyer.update(job_in_progress: false)
    end

    # Start the new pointing flyer for the current meeting.
    if (current_meeting.pointing_flyers.count > 0)
      current_meeting = nil
      @pointing_flyer = nil
    else
      @pointing_flyer = PointingFlyer.new()
      @pointing_flyer.job_in_progress = true
      @pointing_flyer.meeting = current_meeting
      @pointing_flyer.employee = userByLoginNumber
    end


    # raise current_meeting.inspect
    respond_to do |format|
      if @pointing_flyer.save
        format.json { render json: @pointing_flyer.as_json.except!("meeting_id", "created_at", "updated_at").merge!({
            created_at: @pointing_flyer.created_at.strftime("%d/%m/%Y à %H heures %M"),
            updated_at: @pointing_flyer.updated_at.strftime("%d/%m/%Y à %H heures %M"),
            meeting: @pointing_flyer.meeting.as_json.except!("start_date", "end_date").merge!({
                start_date: @pointing_flyer.meeting.start_date.strftime("%d/%m/%Y à %H heures %M"),
                end_date: @pointing_flyer.meeting.end_date.strftime("%d/%m/%Y à %H heures %M"),
            })
        }), status: :ok}
      elsif current_meeting.blank?
        format.json { render json: nil, status: :ok }
      else
        format.json { render json: {error_code: 'ERROR'}, status: :ok }
      end
    end
  end

  def employee_pointing_flyer_end
    # Get the logged employee.
    userByLoginNumber = Employee.public_user(params[:phone_number], params[:login_number]).first

    # Get old pointing flyers in progress and stop them.
    old_pointing_flyer = PointingFlyer.find_by(employee_id: userByLoginNumber.id, job_in_progress: true)
    if old_pointing_flyer.present?
      old_pointing_flyer.update(job_in_progress: false)
    end

    respond_to do |format|
      if old_pointing_flyer.present?
        format.json { render json: old_pointing_flyer.as_json.except!("meeting_id", "created_at", "updated_at").merge!({
             created_at: old_pointing_flyer.created_at.strftime("%d/%m/%Y à %H heures %M"),
             updated_at: old_pointing_flyer.updated_at.strftime("%d/%m/%Y à %H heures %M"),
             meeting: old_pointing_flyer.meeting.as_json.except!("start_date", "end_date").merge!({
                 start_date: old_pointing_flyer.meeting.start_date.strftime("%d/%m/%Y à %H heures %M"),
                 end_date: old_pointing_flyer.meeting.end_date.strftime("%d/%m/%Y à %H heures %M"),
             })
         }), status: :ok }
      else
        format.json { render json: nil, status: :ok }
      end
    end
  end

  # Return companies for the given referent's email.
  def referent_companies
    referent_infos = ReferentInfo.joins(:referent).where(referents: {email: params[:referent_email]}, disabled_at: nil)
    data = Company.joins(:referent_infos).where(referent_infos: {id: referent_infos.pluck(:id)}).pluck("concat(companies.firstname, ' ', companies.lastname)", :id) if referent_infos.present?
    respond_to do |format|
      format.json {
        render json: data
      }
    end
  end

  private
  def get_stats_for_employee(employee_id, company_id)
    dateMonth = DateTime.current.month
    case dateMonth
    when 1
    when 2
    when 3
      start_date = DateTime.new(DateTime.current.year, 1, 1)
      end_date = DateTime.new(DateTime.current.year, 3, 31)
    when 4
    when 5
    when 6
      start_date = DateTime.new(DateTime.current.year, 4, 1)
      end_date = DateTime.new(DateTime.current.year, 6, 31)
    when 7
    when 8
    when 9
      start_date = DateTime.new(DateTime.current.year, 7, 1)
      end_date = DateTime.new(DateTime.current.year, 9, 31)
    else
      start_date = DateTime.new(DateTime.current.year, 10, 1)
      end_date = DateTime.new(DateTime.current.year, 12, 31)
    end
    dates = [
        [DateTime.current.beginning_of_day, DateTime.current.end_of_day],
        [DateTime.current.beginning_of_week, DateTime.current.end_of_week],
        [DateTime.current.beginning_of_month, DateTime.current.end_of_month],
        [DateTime.current.prev_month.beginning_of_month, DateTime.current.prev_month.end_of_month],
        [DateTime.current.beginning_of_quarter, DateTime.current.end_of_quarter],
        [start_date, end_date],
        [DateTime.current.beginning_of_year, DateTime.current.end_of_year],
        [DateTime.current.prev_year.beginning_of_year, DateTime.current.prev_year.end_of_year]
    ]

    times = {day: 0, week: 0, month: 0, prev_month: 0, quarter: 0, semestre: 0, year: 0, prev_year: 0}

    dates.each_with_index do |date, index|
      day_pointing_flyers = PointingFlyer
                                .joins(employee: :informations).includes(employee: :informations).includes(:meeting)
                                .where(employee: {information: {company_id: company_id}}, employee_id: employee_id)
                                .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: date[0], end_date: date[1])
                                .order(updated_at: :desc)

      key = times.keys[index]
      times[key] = 0
      day_pointing_flyers.map do |pointing_flyer|
        times[key] += pointing_flyer.updated_at - pointing_flyer.created_at
      end

    end
    p times

    {
        day_time: format_duration_to_time(times[:day]),
        week_time: format_duration_to_time(times[:week]),
        month_time: format_duration_to_time(times[:month]),
        prev_month_time: format_duration_to_time(times[:prev_month]),
        quarter_time: format_duration_to_time(times[:quarter]),
        semester_time: format_duration_to_time(times[:semestre]),
        year_time: format_duration_to_time(times[:year]),
        lastyear_time: format_duration_to_time(times[:prev_year])
    }
  end
  def monthly_hours(userId)
    current_month_start = DateTime.current.beginning_of_month
    current_month_end = DateTime.current.end_of_month

    pointing_flyers = PointingFlyer
      .joins(:meeting, :employee)
      .where(employees: {id: userId}, meetings: {start_date: current_month_start..current_month_end, end_date: current_month_start..current_month_end})

    duration = 0
    pointing_flyers.map do |pointing_flyer|
      duration = duration + (pointing_flyer.job_in_progress ? (DateTime.current.to_time - pointing_flyer.created_at.to_time) : (pointing_flyer.updated_at.to_time - pointing_flyer.created_at.to_time))
    end
    format_duration_to_time(duration.to_i)
  end

  def company_monthly_hours(userId, companyId)
    current_month_start = DateTime.current.beginning_of_month
    current_month_end = DateTime.current.end_of_month

    pointing_flyers = PointingFlyer
      .joins(meeting: :company).joins(:employee)
      .where(employees: {id: userId}, meetings: {start_date: current_month_start..current_month_end, end_date: current_month_start..current_month_end, companies: {id: companyId}})

    duration = 0
    pointing_flyers.map do |pointing_flyer|
      duration = duration + (pointing_flyer.job_in_progress ? (DateTime.current.to_time - pointing_flyer.created_at.to_time) : (pointing_flyer.updated_at.to_time - pointing_flyer.created_at.to_time))
    end
    format_duration_to_time(duration.to_i)
  end

  def last5_hours_of_month(userId)
    current_date = DateTime.current
    current_month_start = DateTime.current.beginning_of_month

    # pointing_flyers = PointingFlyer
    #   .joins(meeting: :company).joins(:employee)
    #   .order(updated_at: :desc)
    #   .where(employees: {id: userId}, meetings: {start_date: current_month_start..current_month_end, end_date: current_month_start..current_month_end})
    companies = []
    meetings = Meeting
                   .joins(:planning, :company)
                   .order(end_date: :desc)
                   .where(plannings: {employee_id: userId}, start_date: current_month_start..current_date, end_date: current_month_start..current_date).first(5)

    svi_key = 0
    meetings.map do |meeting|
      mCompany = companies.find_all { |company| company['id'] == meeting.company.id}

      if mCompany.blank? && companies.length <= 4

        svi_key += 1
        companies.push(meeting.company.as_json.merge({
          hours_of_month: company_monthly_hours(userId, meeting.company.id),
          svi_key: svi_key
        }))
      end
    end
    companies
  end

  def last5_employees_hours_of_month(companyId)
    current_month_start = DateTime.current.beginning_of_month
    current_month_end = DateTime.current.end_of_month

    employees = Employee
                    .joins(:planning => :meetings)
                    .joins("INNER JOIN information ON information.employee_id = employees.id AND information.company_id = meetings.company_id")
                    .where(meetings: {company_id: companyId, start_date: current_month_start..current_month_end, end_date: current_month_start..current_month_end})
                    .order("meetings.end_date desc").uniq
                    .first(5)

    index = 0
    employees.map do |employee|
      index += 1
      employee.as_json.merge({
                                 hours_of_month: monthly_hours(employee.id),
                                 informations: employee.informations.where(company_id: companyId),
                                 svi_key: index
                             })
    end
  end

  def last3_employees_hours(companyId)
    current_day = DateTime.current
    current_month = DateTime.current
    last_month = DateTime.current - 1.month
    day_svi_key = 0
    month_svi_key = 0
    lastmonth_svi_key = 0

    current_day_employees = Employee
                                .joins(:informations, :planning => [:meetings])
                                .where(information: {company_id: companyId}, planning: {meetings: {company_id: companyId, start_date: current_day.beginning_of_day..current_day.end_of_day, end_date: current_day.beginning_of_day..current_day.end_of_day}})
                                .limit(5).distinct

    current_month_employees = Employee
                                  .joins(:informations).joins(planning: :meetings)
                                  .where(information: {company_id: companyId}, planning: {meetings: {company_id: companyId, start_date: current_month.beginning_of_month..current_month.end_of_month, end_date: current_month.beginning_of_month..current_month.end_of_month}})
                                  .limit(5).distinct
    # raise current_month_employees.inspect

    last_month_employees = Employee
                                  .joins(:informations, :planning => [:meetings])
                                  .where(information: {company_id: companyId}, planning: {meetings: {company_id: companyId, start_date: last_month.beginning_of_month..last_month.end_of_month, end_date: last_month.beginning_of_month..last_month.end_of_month}})
                                  .limit(5).distinct

    data = {
        current_day: {
            svi_key: 1,
            employees: current_day_employees.map do |employee|
              day_svi_key += 1
              current_day_pointing_flyers = PointingFlyer.byEmployeeBetweenTwoDates(employee.id, companyId, current_day.beginning_of_day, current_day.end_of_day)
              employee.as_json.merge({informations: employee.informations.where(company_id: companyId), hours_of_day: get_pointing_flyers_duration(current_day_pointing_flyers), svi_key: day_svi_key})
            end
        },
        current_month: {
            svi_key: 2,
            employees: current_month_employees.map do |employee|
              month_svi_key += 1
              current_month_pointing_flyers = PointingFlyer.byEmployeeBetweenTwoDates(employee.id, companyId, current_month.beginning_of_month, current_month.end_of_month)
              employee.as_json.merge({informations: employee.informations.where(company_id: companyId), hours_of_month: get_pointing_flyers_duration(current_month_pointing_flyers), svi_key: month_svi_key})
            end
        },
        last_month: {
            svi_key: 3,
            employees: last_month_employees.map do |employee|
              lastmonth_svi_key += 1
              last_month_pointing_flyers = PointingFlyer.byEmployeeBetweenTwoDates(employee.id, companyId, last_month.beginning_of_month, last_month.end_of_month)
              employee.as_json.merge({informations: employee.informations.where(company_id: companyId), hours_of_lastmonth: get_pointing_flyers_duration(last_month_pointing_flyers), svi_key: lastmonth_svi_key})
            end
        }
    }
  end

  def get_current_meeting(company)
    current_meeting = Meeting
      .joins(:company, :planning)
      .where("company_id = :companyId AND start_date <= :currentDateTime AND end_date >= :currentDateTime", companyId: company.id, currentDateTime: DateTime.current)
      .order(end_date: :desc)
      .first

    if current_meeting.present?
      current_meeting.as_json.except!("start_date", "end_date")
        .merge({
          start_date: current_meeting.start_date.strftime("%d/%m/%Y à %H heures %M"),
          end_date: current_meeting.end_date.strftime("%d/%m/%Y à %H heures %M"),
          employee: current_meeting.planning.employee.as_json.merge({
                                                                        informations: current_meeting.planning.employee.informations.where(company_id: company.id)
                                                                    }),
          pointing_flyers: current_meeting.pointing_flyers.order(:created_at).map do |pointing_flyer|
            pointing_flyer.as_json.except!("created_at", "updated_at")
                .merge({
                   created_at: pointing_flyer.created_at.strftime("%d/%m/%Y à %H heures %M"),
                   updated_at: pointing_flyer.updated_at.strftime("%d/%m/%Y à %H heures %M"),
                })
          end
        })
    end

    current_meeting
  end

  def get_pointing_flyers_duration(pointing_flyers)
    duration = 0
    pointing_flyers.map do |pointing_flyer|
      duration = duration + (pointing_flyer.job_in_progress ? (DateTime.current.to_time - pointing_flyer.created_at.to_time) : (pointing_flyer.updated_at.to_time - pointing_flyer.created_at.to_time))
    end
    format_duration_to_time(duration.to_i)
  end
end
