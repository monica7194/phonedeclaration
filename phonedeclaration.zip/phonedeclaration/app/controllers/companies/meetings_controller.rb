class Companies::MeetingsController < CompaniesController
  before_action :set_information_and_planning
  before_action :current_company_enable, only: [:create, :update, :destroy]
  def create
    params.require(:meeting).permit(:title, :start_date, :end_date, :frequency, :repeat)

    case params[:meeting][:frequency]
    when 'once'
      newMeeting = {
          title: params[:meeting][:title],
          start_date: Time.zone.parse(params[:meeting][:start_date]),
          end_date: Time.zone.parse(params[:meeting][:end_date]),
          company_id: current_company.id,
          planning: @planning
      }
      @meeting = Meeting.new newMeeting
      if @meeting.valid?
        @planning.meetings << @meeting
      end
    when 'alldays'
      $daysCount = params[:meeting][:repeat].to_i
      $i = 0
      begin
        newMeeting = {
            title: params[:meeting][:title],
            start_date: Time.zone.parse(params[:meeting][:start_date]) + $i.days,
            end_date: Time.zone.parse(params[:meeting][:end_date]) + $i.days,
            company_id: current_company.id,
            planning: @planning
        }
        @meeting = Meeting.new newMeeting
        if @meeting.valid?
          @planning.meetings << @meeting
        end
        $i +=1
      end while $i < $daysCount
    when 'allweekssameday'
      $weeksCount = params[:meeting][:repeat].to_i
      $i = 0
      begin
        newMeeting = {
            title: params[:meeting][:title],
            start_date: Time.zone.parse(params[:meeting][:start_date]) + $i.weeks,
            end_date: Time.zone.parse(params[:meeting][:end_date]) + $i.weeks,
            company_id: current_company.id,
            planning: @planning
        }
        @meeting = Meeting.new newMeeting
        if @meeting.valid?
          @planning.meetings << @meeting
        end
        $i +=1
      end while $i < $weeksCount
    when 'allmonths'
      $monthsCount = params[:meeting][:repeat].to_i
      $i = 0
      begin
        newMeeting = {
            title: params[:meeting][:title],
            start_date: Time.zone.parse(params[:meeting][:start_date]) + $i.months,
            end_date: Time.zone.parse(params[:meeting][:end_date]) + $i.months,
            company_id: current_company.id,
            planning: @planning
        }
        @meeting = Meeting.new newMeeting
        if @meeting.valid?
          @planning.meetings << @meeting
        end
        $i +=1
      end while $i < $monthsCount
    when 'alldaysofweek'
      $weeksCount = params[:meeting][:repeat].to_i
      $weeksLimit = Time.zone.parse(params[:meeting][:start_date]).beginning_of_week + $weeksCount.week
      $i = 0
      $j = Time.zone.parse(params[:meeting][:start_date])
      begin
        if Time.zone.parse(params[:meeting][:start_date]).wday.to_i.in? ([1, 2, 3, 4, 5])
          newMeeting = {
              title: params[:meeting][:title],
              start_date: Time.zone.parse(params[:meeting][:start_date]) + $i.days,
              end_date: Time.zone.parse(params[:meeting][:end_date]) + $i.days,
              company_id: current_company.id,
              planning: @planning
          }
          @meeting = Meeting.new newMeeting
          if @meeting.valid?
            @planning.meetings << @meeting
          end
        end
        $i += 1
        $j = Time.zone.parse(params[:meeting][:start_date]) + $i.days
      end while $j < $weeksLimit
    end
    if @meeting.valid?
      @planning.meetings
    else
      render js: "toastr['error']('#{ @meeting.errors.full_messages.join(', ')}')"
    end
  end

  def update
    @meeting = Meeting.find params[:id]
    unless @meeting.update meeting_params
      render js: "toastr['error']('#{ @meeting.errors.full_messages.join(', ')}')"
    end
  end

  def destroy
    @meeting = Meeting.find_by(id: params[:id])
    if @meeting.present?
      @meeting.destroy
      if @meeting.destroyed?
        flash.now[:notice] = "Le rendez vous a été supprimé"
      else
        flash.now[:notice] = "Il y a eu un problème lors de la suppression"
      end
    end
  end

  private
  def set_information_and_planning
    @information = Information.find params[:information_id]
    @planning = Planning.includes(meetings: :company).includes(:employee).find_by(employee_id: @information.employee_id)
  end
  def meeting_params
    params[:meeting][:start_date] = Time.zone.parse(params[:meeting][:start_date])
    if params[:meeting][:end_date].present?
      params[:meeting][:end_date] = Time.zone.parse(params[:meeting][:end_date])
    end
    params.require(:meeting).permit(:title, :start_date, :end_date)
  end
end
