class Companies::InformationsController < CompaniesController
  before_action :current_company_enable, only: [:create, :update, :disabled, :destroy]
  skip_before_action :get_current_company_or_referent, only: [:employee_by_social_number, :company_by_social_number]
  skip_before_action :get_company_from_session, only: [:employee_by_social_number, :company_by_social_number]
  skip_before_action :company_card_redirect, only: [:employee_by_social_number, :company_by_social_number]
  def index
    respond_to do |format|
      format.html
      format.json { render json: CompaniesEmployeesDatatable.new(view_context, current_company, current_referent) }
    end
  end
  def new
    @employee = Employee.new
    @information = Information.new
  end
  def edit
    @information = Information.find params[:id]
  end
  def create
    generated_password = nil
    @employee = Employee.find_or_create_by({email: params[:employee][:email], social_security_number: params[:employee][:social_security_number]}) do |new_employee|
      generated_password = Devise.friendly_token.first(8)
      new_employee.password = generated_password
    end
    if @employee.persisted?
      UserMailer.employee_registration(@employee, generated_password).deliver_now if generated_password.present?
      @information = Information.find_or_create_by(employee_id: @employee.id, company_id: current_company.id) do |information|
        information.attributes = information_params.merge!({company_id: current_company.id, employee_id: @employee.id})
      end
      if @information.persisted?
        redirect_to companies_informations_path
      else
        flash[:error] = @information.errors.full_messages.join(', ')
        @information = Information.new information_params
        render :new
      end
    else
      flash[:error] = @employee.errors.full_messages.join(', ')
      @information = Information.new information_params
      render :new
    end
  end
  def update
    @information = Information.find params[:id]
    if (@information.update information_params) && (@information.employee.update employee_params)
      redirect_to companies_informations_path
    else
      flash[:error] = @information.errors.full_messages.join(', ')
      render :edit
    end
  end

  def destroy
    @information = Information.find_by(id: params[:id])
    if @information.present?
      meetings = Meeting.joins(:planning => [:employee => :informations]).where(company_id: current_company, information: {id: params[:id]}).where("start_date >= :current_date", current_date: Time.current)
      if meetings.present?
        flash.now[:notice] = "L'employée a encore des missions à effectuer"
      else
        @information.destroy
        if @information.destroyed?
          flash.now[:notice] = "L'employée a été supprimé"
        else
          flash.now[:notice] = "Il y a eu un problème lors de la suppression"
        end
      end
    end
  end

  def disabled
    @information = Information.find params[:id]
    @information.disabled
    flash[:notice] = "Employée #{@information.disabled? ? "désactivé" : "activé"} #{"la désactivation sera effective le " + @information.disabled_at.strftime('%d/%h/%Y') if @information.disabled?}"
    redirect_back fallback_location: root_path
  end
  def employee_by_social_number
    employee = Employee.find_by social_security_number: params[:social_number]
    if employee.present?
      render json: {email: employee.email}, status: 200
    else
      render json: {email: nil}, status: 200
    end
  end
  def company_by_social_number
    company = Company.find_by social_security_number: params[:social_number]
    if company.present?
      render json: {email: company.email}, status: 200
    else
      render json: {email: nil}, status: 200
    end
  end


  def information_params
    params.require(:information).permit(:lastname, :firstname, :delay_margin)
  end
  def employee_params
    params.require(:employee).permit(:email, :social_security_number, :phone_number, :sex, :address_1, :address_2, :city, :postal_code, :country, :birthdate, :birthplace)
  end
end
