class Companies::PlanningsController < CompaniesController
  def index
    @meetings = Meeting.includes(:company).where(company_id: current_company.id)
  end

  def show
    @information = Information.find params[:information_id]
    @planning = Planning.includes(meetings: :company).includes(:employee).find_by(employee: @information.employee_id)
    @planning = Planning.create employee_id: @information.employee_id if @planning.blank?
  end
end
