class Companies::ChargesController < CompaniesController
  before_action :current_company_enable, only: [:create, :update, :destroy]
  def new
  end

  def create
    # Amount in cents
    @amount = 500

    customer = Stripe::Customer.create(
      :email => current_company.email,
      :source  => params[:stripeToken]
    )
    current_company.update stripe_customer_id: customer.id
    charge = Stripe::Charge.create(
      :customer    => current_company.stripe_customer_id,
      :amount      => @amount,
      :description => 'Abonnement fun application',
      :currency    => 'eur'
    )

    lines = {
      'quantity' => 1,
      'unitGrossPrice' => @amount,
      'taxEnabled' => true,
      'taxRate' => 20,
      'productName' => 'test'
    }

    current_company.set_debitoor
    invoice = Debitoor.create_and_send_invoice lines, current_company.debitoor_customer_id, "ludovick@kamini.io", @amount/100.0
    flash[:success] = "paiment effectué"
    redirect_to root_path
  rescue Stripe::CardError => e
    flash[:error] = e.message
    redirect_to new_charge_path
  end

end
