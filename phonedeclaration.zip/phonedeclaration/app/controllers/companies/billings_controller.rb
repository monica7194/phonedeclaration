class Companies::BillingsController < CompaniesController
  skip_before_action :company_card_redirect, only: [:edit, :update]
  before_action :set_prices, only: [:edit, :update, :new, :create]
  def index

    @current_company = Company.find(params[:company_id]) if current_admin.present?
    @charges = Charge.where(company_id: current_company.id)

    respond_to do |format|
      format.html
      format.json { render json: CompaniesChargesDatatable.new(view_context, current_company) }
    end
  end

  def new
    render :edit
  end

  def create
    if params[:id] == 'card'
      create_by_card
    elsif params[:id] == 'bank'
      create_by_bank
    end

  end

  def show
    if current_company.stripe_customer_id.present? && current_company.stripe_card_id.present?
      customer = Stripe::Customer.retrieve(current_company.stripe_customer_id)
      @card = customer.sources.retrieve(current_company.stripe_card_id)
      @bank = Gocardless.get_bank(current_company.gocardless_bank_id) if current_company.gocardless_bank_id.present?
      @exp_card_date = Date.new(@card.exp_year, @card.exp_month).beginning_of_month
      @current_date = (Date.current + 1.month).beginning_of_month

    end
  end

  def edit
  end

  def update
    if params[:id] == 'card'
      create_by_card
    elsif params[:id] == 'bank'
      create_by_bank
    end
  end

  def download_invoice
    charge = Charge.find params[:id]
    pdf = Debitoor.get_pdf_invoice charge.debitoor_invoice_id
    send_data pdf,
    filename: "facture_#{charge.company.fullname}_#{charge.created_at.strftime("%d/%m/%Y")}.pdf",
    type: "application/pdf"
  end

  private
  def create_by_card
    if current_company.stripe_customer_id.present?
      customer = Stripe::Customer.retrieve(current_company.stripe_customer_id)
    else
      customer = Stripe::Customer.create(
          :email => current_company.email
      )
      current_company.update! stripe_customer_id: customer.id
    end
    # customer.sources.create(source: generate_token).id
    token = generate_token
    if token.present?
      begin
        card = customer.sources.create(source: generate_token.id)
        current_company.update! stripe_card_id: card.id
        customer.default_source = card.id
        customer.save
        redirect_to companies_billing_path(id: "card"), flash: {success: "Carte modifiée"}
      rescue => e
        redirect_to edit_companies_billing_path, flash: {error: I18n.translate("stripe.errors.#{e.code}")}
      end
    else
      redirect_to edit_companies_billing_path
    end
  end

  def create_by_bank
    if current_company.gocardless_customer_id.present?
      customer = Gocardless.get_customer(current_company.gocardless_customer_id)
    else
      if current_company.firstname.present? && current_company.lastname.present?
        customer = Gocardless.create_customer current_company.lastname, current_company.firstname, current_company.email
      else
        current_company.update firstname: params[:firstname], lastname: params[:lastname]
        customer = Gocardless.create_customer current_company.lastname, current_company.firstname, current_company.email
      end
      current_company.update gocardless_customer_id: customer.id
    end
    # customer.sources.create(source: generate_token).id
    begin
      account_holder_name = params[:account_holder_name]||current_company.fullname
      last_charge = current_company.charges.order(:created_at).last
      if last_charge.present?
        if last_charge.gocardless_payment_id.present?
          payment = Gocardless.get_payment last_charge.gocardless_payment_id
          p payment, "date", payment.charge_date.to_date,
          if payment.status != 'pending_customer_approval' &&payment.status != 'pending_submission'
            Gocardless.disable_bank current_company if current_company.gocardless_bank_id.present?
          else
            p payment.charge_date.to_date
            if payment.charge_date.to_date < Time.now #charge date pass
              Gocardless.disable_bank current_company if current_company.gocardless_bank_id.present?
            end
          end
        else
          Gocardless.disable_bank current_company if current_company.gocardless_bank_id.present?
        end
      else
        Gocardless.disable_bank current_company if current_company.gocardless_bank_id.present?
      end
      bank = Gocardless.create_bank account_holder_name, params[:iban], current_company.gocardless_customer_id
      current_company.update gocardless_bank_id: bank.id

      # if current_company.gocardless_mandate_id.present?
      #   payment = Gocardless.create_payment (10 * 100), 'MVP Phone Application', current_company.gocardless_mandate_id
      # else
      #   mandate = Gocardless.create_mandate current_company.gocardless_bank_id
      #   current_company.update gocardless_mandate_id: mandate.id
      #   payment = Gocardless.create_payment (10 * 100), 'MVP Phone Application', current_company.gocardless_mandate_id
      # end
      # Charge.create company: current_company, debitoor_invoice_id: 'nil', gocardless_payment_id: payment.id, name: current_company.denomination, state: 1, amount: 10
      redirect_to companies_billing_path(id: "bank"), flash: {success: "Banque ajoutée"}
    rescue => e
      p e
      if e.is_a? GoCardlessPro::ValidationError
        redirect_to new_companies_billing_path, flash: {notice: I18n.t("gocardless.errors.#{e.errors[0]["reason"]}")}
      else
        redirect_to new_companies_billing_path, flash: {notice: "Il y a eu un problème"}
      end
    end
  end
  def set_prices
    @prices = AdminPrice.variables
    fix_price = AdminPrice.fixes.first
    @fix_price = fix_price.present? ? fix_price.amount : 0
  end
  def generate_token
    begin
      Stripe::Token.create(
          card: {
              number: params[:card_number],
              exp_month: params[:card_month],
              exp_year: params[:card_year],
              cvc: params[:card_cvx]
          }
      )
    rescue => e
      flash[:error] = I18n.translate("stripe.errors.#{e.code}")
      false
    end
  end
end
