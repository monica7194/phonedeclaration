class Companies::ReferentsController < CompaniesController
  layout "companies"
  before_action :set_referent, only: [:show, :edit, :update, :destroy]
  before_action :current_company_enable, only: [:create, :update, :destroy]

  # GET /referents
  # GET /referents.json
  def index
    respond_to do |format|
      format.html
      format.json { render json: CompaniesReferentsDatatable.new(view_context, current_company, current_referent) }
    end
  end

  # GET /referents/new
  def new
    @referent = Referent.new
    @referent_info = ReferentInfo.new
  end

  # GET /referents/1/edit
  def edit
    @referent = Referent.joins(:referent_infos).where(id: params[:id], referent_infos: {company_id: current_company.id}).first
  end

  # POST /referents
  # POST /referents.json
  def create
    generated_password = nil
    @referent = Referent.find_or_create_by(email: params[:referent][:email]) do |new_referent|
      generated_password = Devise.friendly_token.first(8)
      new_referent.password = generated_password
      new_referent.attributes = referent_params
    end
    if  @referent.persisted?
      UserMailer.referent_registration(@referent, generated_password).deliver_now if generated_password.present?
      @referent_info = ReferentInfo.find_or_create_by(referent_id: @referent.id, company_id: current_company.id) do |referent_info|
        referent_info.attributes = referent_info_params.merge!({company_id: current_company.id, referent_id: @referent.id})
      end

      if @referent_info.persisted?
        redirect_to companies_referents_path
      else
        flash[:error] = @referent.errors.full_messages.join(', ')
        @referent_info = ReferentInfo.new referent_info_params
        render :new
      end
    else
      flash[:error] = @referent.errors.full_messages.join(', ')
      @referent = Referent.new referent_params
      render :new
    end
  end

  # PATCH/PUT /referents/1
  # PATCH/PUT /referents/1.json
  def update
    @referent = Referent.joins(:referent_infos).where(id: params[:id], referent_infos: {company_id: current_company.id}).first
    if @referent.update referent_params

      @referent_info = ReferentInfo.find_by(company_id: current_company.id, referent_id: @referent.id)

      if @referent_info.update referent_info_params
        redirect_to companies_referents_path
      else
        flash[:error] = @referent_info.errors.full_messages.join(', ')
        render :edit
      end
    else
      flash[:error] = @referent.errors.full_messages.join(', ')
      render :edit
    end
  end

  # DELETE /referents/1
  # DELETE /referents/1.json
  def destroy
    @referent_info = ReferentInfo.find_by(company_id: current_company.id, referent_id: @referent.id)
    @referent_info.disabled
    redirect_back fallback_location: root_path, notice:  "Le référent a été #{@referent_info.disabled? ? "désactivé" : "activé"}"
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_referent
      @referent = Referent.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def referent_params
      # params.fetch(:referent, {})
      params.require(:referent).permit(:firstname, :lastname, :email, :address_1, :address_2, :city, :postal_code, :country, :phone_number)
    end

  def referent_info_params
    params.require(:referent_info).permit(:relation)
  end
end
