class Companies::PointingFlyersController < CompaniesController
  layout "companies"
  # before_action :authenticate_employee!
  # before_action :set_pointing_flyer, only: [:show, :edit, :update, :destroy]

  # GET /pointing_flyers
  # GET /pointing_flyers.json
  def index
    @employee = Employee.employee_by_information(params[:information_id]).first
    if current_admin.present?
      if params[:range_start].present? && params[:range_end].present?
        @pointing_flyers = PointingFlyer
                               .joins(employee: :informations).includes(employee: :informations).includes(meeting: [:company])
                               .where(employee: {information: {id: params[:information_id]}})
                               .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                               .order(updated_at: :desc)
      else
        @pointing_flyers = PointingFlyer
                               .joins(employee: :informations).includes(employee: :informations).includes(meeting: [:company])
                               .where(employee: {information: {id: params[:information_id]}})
                               .order(updated_at: :desc)
      end
      @stats = get_stats(params[:information_id])
    else
      if params[:range_start].present? && params[:range_end].present?
        @pointing_flyers = PointingFlyer
                               .joins(employee: :informations).includes(employee: :informations).includes(meeting: [:company])
                               .where(employee: {information: {id: params[:information_id]}})
                               .where(companies: {id: current_company.id})
                               .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                               .order(updated_at: :desc)
      else
        @pointing_flyers = PointingFlyer
                               .joins(employee: :informations).includes(employee: :informations).includes(meeting: [:company])
                               .where(employee: {information: {id: params[:information_id]}})
                               .where(companies: {id: current_company.id})
                               .order(updated_at: :desc)
      end
      @stats = get_stats(params[:information_id], current_company.id)
    end



    respond_to do |format|
      format.html
      format.json { render json: CompaniesPointingFlyersDatatable.new(view_context, current_admin.present?, current_company) }
      format.js
      format.pdf do
        render pdf: "pointing_flyers",
          encoding: "UTF-8",
          margin: {left: 0, right: 0, bottom: 0, top: 0},
          layout: 'pdf.html',
          disposition: 'attachment'
      end
    end
  end

  def all
    if params[:range_start].present? && params[:range_end].present?
      @pointing_flyers = PointingFlyer
                             .joins(:meeting).includes(:meeting)
                             .joins(employee: :informations).includes(employee: :informations)
                             .where(employee: {information: {company_id: current_company.id}}, meetings: {company_id: current_company.id})
                             .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: params[:range_start].to_date, end_date: params[:range_end].to_date)
                             .order(updated_at: :desc)
    else
      @pointing_flyers = PointingFlyer
                             .joins(:meeting)
                             .joins(employee: :informations)
                             .where(employee: {information: {company_id: current_company.id}}, meetings: {company_id: current_company.id})
                             .order(updated_at: :desc)
    end

    @stats = get_all_stats(current_company.id)

    respond_to do |format|
      format.html
      format.json { render json: CompaniesAllPointingFlyersDatatable.new(view_context, current_company) }
      format.pdf do
        render pdf: "pointing_flyers",
          encoding: "UTF-8",
          margin: {left: 0, right: 0, bottom: 0, top: 0},
          layout: 'pdf.html',
          disposition: 'attachment'
      end
      format.js
    end
  end

  private

  def get_all_stats(company_id)
    dateMonth = DateTime.current.month
    case dateMonth
    when 1
    when 2
    when 3
      start_date = DateTime.new(DateTime.current.year, 1, 1)
      end_date = DateTime.new(DateTime.current.year, 3, 31)
    when 4
    when 5
    when 6
      start_date = DateTime.new(DateTime.current.year, 4, 1)
      end_date = DateTime.new(DateTime.current.year, 6, 31)
    when 7
    when 8
    when 9
      start_date = DateTime.new(DateTime.current.year, 7, 1)
      end_date = DateTime.new(DateTime.current.year, 9, 31)
    else
      start_date = DateTime.new(DateTime.current.year, 10, 1)
      end_date = DateTime.new(DateTime.current.year, 12, 31)
    end
    dates = [
      [DateTime.current.beginning_of_day, DateTime.current.end_of_day],
      [DateTime.current.beginning_of_week, DateTime.current.end_of_week],
      [DateTime.current.beginning_of_month, DateTime.current.end_of_month],
      [DateTime.current.prev_month.beginning_of_month, DateTime.current.prev_month.end_of_month],
      [DateTime.current.beginning_of_quarter, DateTime.current.end_of_quarter],
      [start_date, end_date],
      [DateTime.current.beginning_of_year, DateTime.current.end_of_year],
      [DateTime.current.prev_year.beginning_of_year, DateTime.current.prev_year.end_of_year]
    ]

    times = {day: 0, week: 0, month: 0, prev_month: 0, quarter: 0, semestre: 0, year: 0, prev_year: 0}

    dates.each_with_index do |date, index|
      day_pointing_flyers = PointingFlyer
                                     .joins(employee: :informations).includes(employee: :informations).includes(:meeting => [:company])
                                     .where(employee: {information: {company_id: company_id}})
                                     .where(companies: {id: current_company.id})
                                     .where("pointing_flyers.created_at >= :start_date AND pointing_flyers.updated_at <= :end_date", start_date: date[0], end_date: date[1])
                                     .order(updated_at: :desc)

      key = times.keys[index]
      times[key] = 0
      day_pointing_flyers.map do |pointing_flyer|
        times[key] += pointing_flyer.updated_at - pointing_flyer.created_at
      end

    end
    p times

    {
        day_time: format_duration_to_time(times[:day]),
        week_time: format_duration_to_time(times[:week]),
        month_time: format_duration_to_time(times[:month]),
        prev_month_time: format_duration_to_time(times[:prev_month]),
        quarter_time: format_duration_to_time(times[:quarter]),
        semester_time: format_duration_to_time(times[:semestre]),
        year_time: format_duration_to_time(times[:year]),
        lastyear_time: format_duration_to_time(times[:prev_year])
    }
  end
end
