class EmployeesController < ApplicationController
  layout "employees"
  before_action :authenticate_employee_or_admin!

  def authenticate_employee_or_admin!
    if current_employee.blank? && current_admin.blank?
      authenticate_employee!
    end
  end

  def update
    filter_params = params[:employee][:password].present? ? employee_params : employee_params.except(:password)
    if current_employee.update filter_params
      sign_in(current_employee, :bypass => true) if params[:employee][:password].present?
      redirect_back fallback_location: root_path
    else
      flash.now[:error] = current_employee.errors.full_messages.join(', ')
      render :edit
    end
  end

  # inheritance controllers methods
  def set_planning
    @current_employee = Employee.find params[:employee_id] if current_employee.blank? && (params[:employee_id].present? ||params[:id])
    @planning = Planning.includes(meetings: :company).includes(:employee).find_by(employee: current_employee.id)
    @planning = Planning.create employee_id: current_employee.id if @planning.blank?
    if params[:company_id].present?
      @meetings = @planning.meetings.where(company_id: params[:company_id]).or(@planning.meetings.where(company_id: nil))
    else
      @meetings = @planning.meetings
    end
    @company_id = params[:company_id]
  end

  def pointing_flyer
  end

  def pointing_flyer_patch

  end

  private
  def employee_params
    params.require(:employee).permit(:email, :password, :phone_number, :phone_number, :sex, :address_1, :address_2, :city, :postal_code, :country, :birthdate, :birthplace)
  end
end
