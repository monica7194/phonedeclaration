class CompaniesController < ApplicationController
  layout "companies"
  before_action :get_current_company_or_referent
  before_action :get_company_from_session
  before_action :company_card_redirect

  def get_current_company_or_referent
    if current_company.blank? && current_referent.blank? && current_admin.blank?
      authenticate_company!
    end
  end

  def current_company_enable
    if current_company.present? &&current_company.disabled? && (current_company.disabled_at <= DateTime.current)
      flash[:notice] = "Votre compte n'est plus activé"
      redirect_back fallback_location: root_path
    end
  end
  def company_card_redirect
    if current_company.present? && (current_referent.blank? ||current_admin.blank?) && (current_company.stripe_card_id.blank? &&current_company.gocardless_bank_id.blank?)
     redirect_to edit_companies_billing_path(current_company.id)
    end
  end
end
