class Admins::ReferentsController < AdminsController
  before_action :set_referent, only: [:edit, :update, :destroy]
  before_action :set_company_id
  before_action :set_relation_options, only: [:edit, :update, :new, :create]

  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminsReferentsDatatable.new(view_context) }
    end
  end

  def new
    @referent = Referent.new
    @referent_info = ReferentInfo.new
  end

  def edit
    # @referent = Referent.includes(:companies).references(:companies).find_by(companies: {id: @company_id}, referent_id: @referent.id) if @company_id.present?
    @referent_info = ReferentInfo.find_by(company_id: @company_id, referent_id: @referent.id) if @company_id.present?
  end

  def create
    @referent = Referent.find_by(email: params[:referent][:email]) || Referent.new(referent_params)
    password = params[:referent][:password] || Devise.friendly_token.first(8)
    @referent.password = password if @referent.new_record?
    respond_to do |format|
      @referent.attributes = referent_params unless @referent.new_record?
      if @referent.save
        UserMailer.referent_registration(@referent, password).deliver_now
        format.html do
          if @company_id.present?
            redirect_to admins_company_referents_path(company_id: @company_id), notice: "Le compte référent a été créé"
          else
            redirect_to admins_referents_path, notice: "Le compte référent a été créé"
          end
        end
      else
        flash.now[:alert] = @referent.errors.full_messages.join(', ')
        format.html { render :new }
      end
    end
  end

  def update
    referent_params_with_password = referent_params.merge!(password: params[:referent][:password]) if params[:referent][:password].present?
    respond_to do |format|
      if @referent.update(referent_params_with_password || referent_params)
        format.html do
          if @company_id.present?
            redirect_to admins_company_referents_path(company_id: @company_id), notice: "Le compte référent a été modifié"
          else
            redirect_to edit_admins_referent_path, notice: "Le compte référent a été modifié"
          end
        end
        format.json { render :index }
      else
        flash.now[:alert] = @referent.errors.full_messages.join(', ')
        format.html { render :edit }
        format.json { render json: @referent.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    if @referent.referent_infos.blank?
      @referent.destroy
      flash_message = @referent.destroyed? ? "Le référent a été supprimé" : "Il y a eu un problème lors de la suppression"
    else
      flash_message =  "Le compte référent n'est pas vierge"
    end
    respond_to do |format|
      format.html do
        if @company_id.present?
          redirect_to admins_company_referents_path(company_id: @company_id), notice: flash_message
        else
          redirect_to admins_referents_path, notice: flash_message
        end
      end
      format.json { head :no_content }
    end
  end

  private
  def set_referent
    @referent = Referent.find(params[:id])
  end
  def set_relation_options
    @relation_options = [
        [I18n.t("other.relation.brother"), "BROTHER"],
        [I18n.t("other.relation.sister"), "SISTER"],
        [I18n.t("other.relation.father"), "FATHER"],
        [I18n.t("other.relation.mother"), "MOTHER"],
        [I18n.t("other.relation.grand_parent"), "GRAND_PARENT"],
        [I18n.t("other.relation.social_worker"), "SOCIAL_WORKER"],
        [I18n.t("other.relation.personal_service_company"), "PERSONAL_SERVICE_COMPANY"]
    ]
  end
  def set_company_id
    @company_id = params[:company_id]
  end

  def referent_params
    # params.fetch(:referent, {})
    params.require(:referent).permit(:firstname, :lastname, :email, :address_1, :address_2, :city, :postal_code, :country, :phone_number, :referent_infos_attributes => [:relation, :id, :company_id])
  end
end
