class Admins::ChargesController < AdminsController
  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminsChargesDatatable.new(view_context) }
    end
  end

end
