class Admins::AdminPricesController < AdminsController
  before_action :set_admin_price, only: [:show, :edit, :update, :destroy]
  before_action :set_nb_salaries_options, only: [:edit, :update, :new, :create]
  before_action :set_max, only: [:edit, :update, :new, :create]

  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminPricesDatatable.new(view_context) }
    end
  end

  def new
    @admin_price = AdminPrice.new
  end

  def edit
  end

  def create
    @admin_price = AdminPrice.new(admin_price_params)
    respond_to do |format|
      if @admin_price.save
        format.html {redirect_to admins_admin_prices_path, notice: "Le prix a été créé"}
      else
        flash.now[:alert] = @admin_price.errors.full_messages.join(', ')
        format.html { render :new }
      end
    end
  end

  def update
    respond_to do |format|
      if @admin_price.update(admin_price_params)
        format.html {redirect_to admins_admin_prices_path, notice: "Le prix a été modifié"}
        format.json { render :show, status: :ok, location: @referent }
      else
        flash.now[:alert] = @admin_price.errors.full_messages.join(', ')
        format.html { render :edit }
        format.json { render json: @admin_price.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
      @admin_price.destroy
      flash_message = @admin_price.destroyed? ? "Le prix a été supprimé" : "Il y a eu un problème lors de la suppression"
    respond_to do |format|
      format.html {redirect_to admins_admin_prices_path, notice: flash_message}
      format.json { head :no_content }
    end
  end

  private
  def set_admin_price
    @admin_price = AdminPrice.find(params[:id])
  end
  def set_nb_salaries_options
    @nb_salaries_options = AdminPrice.nb_salaries_options
  end
  def set_max
    @max = AdminPrice.count + 1
  end
  def admin_price_params
    # params.fetch(:referent, {})
    params.require(:admin_price).permit(:amount, :amount_type, :amount_for, :show_order)
  end
end
