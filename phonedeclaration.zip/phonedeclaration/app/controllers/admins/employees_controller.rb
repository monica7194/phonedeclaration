class Admins::EmployeesController < AdminsController
  before_action :set_employee, only: [:show, :edit, :update, :destroy, :hours_history, :pointing_flyers]
  before_action :set_company_id

  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminsEmployeesDatatable.new(view_context) }
    end
  end

  def new
    @employee = Employee.new
    @information = Information.new if @company_id.present?
  end

  def edit
    @information = Information.find_by(company_id: @company_id, employee_id: @employee.id) if @company_id.present?
  end

  def create
    @employee = Employee.find_by(email: params[:employee][:email], social_security_number: params[:employee][:social_security_number]) || Employee.new(employee_params)
    password = params[:employee][:password] || Devise.friendly_token.first(8)
    @employee.password = password if @employee.new_record?
    respond_to do |format|
      @employee.attributes = employee_params
      if @employee.save
        UserMailer.employee_registration(@employee, password).deliver_now
        format.html do
          if @company_id.present?
            redirect_to admins_company_employees_path(company_id: @company_id), notice: "Le compte employé a été créé"
          else
            redirect_to admins_employees_path, notice: "Le compte employé a été créé"
          end
        end
      else
        flash.now[:alert] = @employee.errors.full_messages.join(', ')
        format.html { render :new }
      end
    end
  end

  def update
    employee_params_with_password = employee_params.merge!(password: params[:employee][:password]) if params[:employee][:password].present?
    respond_to do |format|
      if @employee.update(employee_params_with_password || employee_params)
        format.html do
          if @company_id.present?
            redirect_to admins_company_employees_path(company_id: @company_id), notice: "Le compte employé a été modifié"
          else
            redirect_to admins_employees_path, notice: "Le compte employé a été modifié"
          end
        end
        format.json { render :show, status: :ok, location: @employee }
      else
        flash.now[:alert] = @employee.errors.full_messages.join(', ')
        format.html { render :edit }
        format.json { render json: @employee.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    if @employee.informations.blank? && @employee.planning.blank? && @employee.pointing_flyers.blank?
      @employee.destroy
      flash_message = @employee.destroyed? ? "L'employé a été supprimé" : "Il y a eu un problème lors de la suppression"
    else
      flash_message =  "Le compte employé n'est pas vierge"
    end
    respond_to do |format|
      format.html { redirect_to admins_employees_path, notice: flash_message }
      format.json { head :no_content }
    end
  end

  def show
    @current_employee = @employee
    @planning = @current_employee.planning || Planning.create(employee_id: @current_employee)
    @options_for_company_select = current_employee.companies.pluck("concat(companies.firstname, ' ', companies.lastname)", :id)
    @options_for_company_select.unshift ["Arret maladie", Meeting::DAY_OFF_REASON[:sick_leave]]
    @options_for_company_select.unshift ["Jour de congé", Meeting::DAY_OFF_REASON[:day_off]]
    @meetings = @planning.meetings
    @employee_id = @current_employee.id
    render "employees/plannings/index"
  end


  def hours_history
    @current_employee = @employee
    render "employees/hours_history/index"
  end

  private
  def set_employee
    @employee = Employee.find(params[:id])
  end

  def set_company_id
    @company_id = params[:company_id]
  end

  def employee_params
    params.require(:employee).permit(:email, :social_security_number, :phone_number, :sex, :address_1, :address_2, :city, :postal_code, :country, :birthdate, :birthplace, :nationality, informations_attributes: [:id, :company_id, :firstname, :lastname])
  end
end
