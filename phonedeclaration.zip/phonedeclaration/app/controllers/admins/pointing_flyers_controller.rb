class Admins::PointingFlyersController < AdminsController
  before_action :set_pointing_flyer, only: [:edit, :update, :destroy]
  before_action :set_options_for_meeting_select, only: [:edit, :update, :new, :create]

  def index
    @current_employee = Employee.find params[:employee_id]
    if @current_employee.informations.present?
      @employee = @current_employee
      @information_id = (@current_employee.informations.first if @current_employee.informations.present?)
      @stats = get_stats(@information_id)
      render "companies/pointing_flyers/index"
    else
      redirect_back fallback_location: admins_employees_path, notice: "Cet employé n'a pas encore d'employeur"
    end
  end

  def edit
  end

  def new
    @pointing_flyer = PointingFlyer.new job_in_progress: true
  end

  def create
    @pointing_flyer = PointingFlyer.find_by meeting_id: params[:pointing_flyer][:meeting_id]
    if @pointing_flyer.present?
      @pointing_flyer.attributes = pointing_flyer_params
    else
      @pointing_flyer = PointingFlyer.new pointing_flyer_params.merge(employee_id: params[:employee_id])
    end
    if @pointing_flyer.save
      flash[:notice] = "Le pointage a été créer"
      redirect_to pointing_flyers_admins_employee_path(params[:employee_id])
    else
      flash.now[:alert] = @pointing_flyer.errors.full_messages.join(', ')
      render :new
    end
  end

  def update
    @pointing_flyer.attributes = pointing_flyer_params
    if @pointing_flyer.save
      flash[:notice] = "Le pointage a été modifié"
      redirect_to pointing_flyers_admins_employee_path(id: @pointing_flyer.employee_id)
    else
      flash.now[:alert] = @pointing_flyer.errors.full_messages.join(', ')
      render :edit
    end
  end

  def destroy
    @pointing_flyer.destroy
    flash[:notice] = @pointing_flyer.destroyed? ? "Le pointage a été supprimé" : "Il y a eu un problème lors de la suppression"
    respond_to do |format|
      format.html { redirect_back(fallback_location: admins_admins_path) }
    end
  end

  private
  def set_pointing_flyer
    @pointing_flyer = PointingFlyer.find(params[:id])
  end

  def set_options_for_meeting_select
    date_format = "DD/MM/YYYY HH24:MI"
    @options_for_meeting_select = Meeting.joins(:planning).where(plannings: {employee_id: params[:employee_id]}).pluck("concat(title, ' ', TO_CHAR(start_date, '#{date_format}'), ' - ', TO_CHAR(end_date, '#{date_format}'))", :id)
  end

  def pointing_flyer_params
    params.require(:pointing_flyer).permit(:created_at, :updated_at, :job_in_progress, :meeting_id)
  end
end
