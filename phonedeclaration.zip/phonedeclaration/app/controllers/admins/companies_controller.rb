class Admins::CompaniesController < AdminsController
  before_action :set_company, only: [:show, :edit, :update, :destroy, :billings]

  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminsCompaniesDatatable.new(view_context) }
    end
  end

  def new
    @company = Company.new
  end

  def create
    @company = Company.new(company_params)
    password = params[:company][:password] || Devise.friendly_token.first(8)
    @company.password = password
    respond_to do |format|
      if @company.save
        UserMailer.company_registration(@company, password).deliver_now
        format.html { redirect_to admins_companies_path, notice: "Le compte employeur a été créé" }
      else
        flash.now[:alert] = @company.errors.full_messages.join(', ')
        format.html { render :new }
      end
    end
  end

  def update
    company_params_with_password = company_params.merge!(password: params[:company][:password]) if params[:company][:password].present?
    respond_to do |format|
      if @company.update(company_params_with_password || company_params)
        format.html { redirect_to admins_companies_path, notice: "Le compte employeur a été modifié" }
        format.json { render :show, status: :ok, location: @company }
      else
        flash.now[:alert] = @company.errors.full_messages.join(', ')
        format.html { render :edit }
        format.json { render json: @company.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    # if @company.informations.blank? && @company.referent_infos.blank? && @company.charges.blank?
    if @company.disabled?
      @company.update disabled_at: nil
    else
      @company.update disabled_at: Time.now
    end
    flash_message = @company.disabled? ? "L'employeur a été désactivé" : "L'employeur a été activé"
    # else
    #   flash_message =  "Le compte employeur n'est pas vierge"
    # end
    respond_to do |format|
      format.html { redirect_to admins_companies_path, notice: flash_message }
      format.json { head :no_content }
    end
  end

  def show
    @current_company = @company
    @meetings = Meeting.includes(:company).where(company_id: @current_company.id)
    render "companies/plannings/index"
  end

  def billings
    @current_company = @company
    @charges = Charge.where(company_id: @current_company.id)
    render "companies/billings/index"
  end

  private
  def set_company
    @company = Company.find(params[:id])
  end

  def company_params
    params.require(:company).permit(:email, :firstname, :lastname, :birthdate, :birthplace, :exonerations, :address_1, :address_2, :city, :country, :postal_code, :phone_number, :gsm_number, :nationality, :social_security_number)
  end

end
