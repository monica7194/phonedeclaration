class Admins::AdminsController < AdminsController
  before_action :set_admin, only: [:show, :edit, :update, :destroy]

  def index
    respond_to do |format|
      format.html
      format.json { render json: AdminsDatatable.new(view_context) }
    end
  end

  def new
    @admin = Admin.new
  end

  def create
    @admin = Admin.new(admin_params)
    password = params[:admin][:password] || Devise.friendly_token.first(8)
    @admin.password = password
    respond_to do |format|
      if @admin.save
        UserMailer.admin_registration(@admin, password).deliver_now
        format.html { redirect_to admins_admins_path, notice: "Le compte administrateur a été créé" }
      else
        flash.now[:alert] = @admin.errors.full_messages.join(', ')
        format.html { render :new }
      end
    end
  end

  def update
    admin_params_with_password = admin_params.merge!(password: params[:admin][:password]) if params[:admin][:password].present?
    respond_to do |format|
      if @admin.update(admin_params_with_password || admin_params)
        format.html { redirect_to admins_admins_path, notice: "Administrateur modifié" }
        format.json { render :show, status: :ok, location: @admin }
      else
        flash.now[:alert] = @admin.errors.full_messages.join(', ')
        format.html { render :edit }
        format.json { render json: @admin.errors, status: :unprocessable_entity }
      end
    end
  end

  def destroy
    if @admin.id != current_admin.id
      @admin.destroy
      flash_message = @admin.destroyed? ? "L'administrateur a été supprimé" : "Il y a eu un problème lors de la suppression"
    else
      flash_message = "Vous ne pouvez pas vous supprimer"
    end
    respond_to do |format|
      format.html { redirect_to admins_admins_path, notice: flash_message }
      format.json { head :no_content }
    end
  end

  private
  def set_admin
    @admin = Admin.find(params[:id])
  end

  def admin_params
    params.require(:admin).permit(:email, :firstname, :lastname)
  end

end
