class Information < ApplicationRecord
  belongs_to :company
  belongs_to :employee
  validates_uniqueness_of :employee_id, :scope => :company_id
  def email
    self.employee.present? ? self.employee.email : nil
  end
  def social_security_number
    self.employee.present? ? self.employee.social_security_number : nil
  end
  def phone_number
    self.employee.present? ? self.employee.phone_number : nil
  end

  def disabled?
    disabled_at.present?
  end
  def not_disabled?
    !disabled?
  end
  def fullname
    "#{firstname} #{lastname}"
  end
  def disabled
    if disabled?
      self.update_attribute('disabled_at', nil)
    else
      self.update_attribute('disabled_at', 1.month.from_now)
    end
  end
end
