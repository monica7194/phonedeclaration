class PointingFlyer < ApplicationRecord
  belongs_to :meeting
  belongs_to :employee
  # validate :check_for_multiple_jobs, on: :create
  #
  # def check_for_multiple_jobs
  #   current_pointing_flyer = PointingFlyer.find_by job_in_progress: true
  #   if (current_pointing_flyer.present?)
  #     errors["job_in_progress"] << I18n.t('pointing_flyer.cannot_start_2_jobs')
  #   end
  # end

  def serializeSVI
    json = self.as_json.except!("created_at", "updated_at")
    json.merge!({
      created_at: created_at.strftime("%d/%m/%Y à %H heures %M"),
      updated_at: updated_at.strftime("%d/%m/%Y à %H heures %M"),
      meeting: meeting
    })
  end

  def late?
    late_time < 0
  end

  # def late_with_notification
  #   information = employee.information_by_company(meeting.company_id)
  #   if information.present? &&information.delay_margin.present?
  #     if (meeting.start_date + information.delay_margin.minute) <= created_at
  #       UserMailer.pointing_flyer_late self
  #     end
  #   end
  # end

  def late_time
    information = employee.detect_information_by_company(meeting.company_id)
    if information.present? &&information.delay_margin.present?
      time = (meeting.start_date + information.delay_margin.minute - created_at)
    else
      time = (meeting.start_date - created_at)
    end
  end

  def late_time_abs
    late_time.abs
  end
  def over_work?
    over_work_time < 0
  end

  def over_work_time
    information = employee.detect_information_by_company(meeting.company_id)
    if information.present? &&information.delay_margin.present?
      time = (meeting.end_date + information.delay_margin.minute - updated_at)
    else
      time = (meeting.end_date - updated_at)
    end
  end

  def over_work_time_abs
    over_work_time.abs
  end

  scope :byEmployeeBetweenTwoDates, ->(userId, companyId, start_date, end_date) do
    joins(:meeting, :employee).where(employees: {id: userId}, meetings: {company_id: companyId, start_date: start_date..end_date, end_date: start_date..end_date})
  end
end
