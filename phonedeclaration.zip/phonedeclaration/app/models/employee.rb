class Employee < ApplicationRecord
  UID_RANGE = ('0'..'9').to_a
  generate_public_uid generator: PublicUid::Generators::RangeString.new(6, UID_RANGE)
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable,
         :recoverable, :rememberable, :trackable, :validatable

  validates :email, uniqueness: true, presence: true
  validates :social_security_number, uniqueness: true, presence: true
  # validate :social_security_number_format

  GENDER = {
      male: 0,
      female: 1
  }

  def social_security_number_format
    #1 2 3 7 or 8 for sex
    #([0-9]{2}) birthdate year ( aa )
    #(0[0-9]|[2-35-9][0-9]|[14][0-2]) month (mm)
    #((0[1-9]|[1-8][0-9]|9[0-69]|2[abAB])(00[1-9]|0[1-9][0-9]|[1-8][0-9]{2}|9[0-8][0-9]|990)|(9[78][0-9])(0[1-9]|[1-8][0-9]|90)) postal code
    #(00[1-9]|0[1-9][0-9]|[1-9][0-9]{2}) birth order number
    #(0[1-9]|[1-8][0-9]|9[0-7]) key control
    sex = "([1-47-8])"
    birthdate_year = "([0-9]{2})"
    birthdate_month = "(0[0-9]|[2-35-9][0-9]|[14][0-2])"
    postal_code = "((0[1-9]|[1-8][0-9]|9[0-69]|2[abAB])(00[1-9]|0[1-9][0-9]|[1-8][0-9]{2}|9[0-8][0-9]|990)|(9[78][0-9])(0[1-9]|[1-8][0-9]|90))"
    birth_order_number = "(00[1-9]|0[1-9][0-9]|[1-9][0-9]{2})"
    key_control = "(0[1-9]|[1-8][0-9]|9[0-7])"
    valid_regex = Regexp.new("#{sex}#{birthdate_year}#{birthdate_month}#{postal_code}#{birth_order_number}#{key_control}")
    if french? &&social_security_number.present? and not social_security_number.match(valid_regex)
      errors.add :social_security_number, I18n.t("not_valid_format")
    end
  end
  has_many :informations
  has_many :companies, through: :informations, dependent: :destroy
  accepts_nested_attributes_for :informations
  has_one :planning
  has_many :pointing_flyers, dependent: :destroy

  scope :monthly_active, ->(current_company_id) do
    current_datetime = DateTime.current - 1.month
    current_datetime.beginning_of_month..current_datetime.end_of_month
    joins(:planning => :meetings)
    .where("meetings.company_id = :current_company_id", {current_company_id: current_company_id})
    .where("(meetings.start_date BETWEEN :begin AND :end OR meetings.end_date BETWEEN :begin AND :end)", {
        begin: current_datetime.beginning_of_month,
        end: current_datetime.end_of_month
    })
    .distinct
  end

  scope :public_user, ->(phone_number, login_number) do
    joins(informations: :company).where(public_uid: login_number, companies: {phone_number: phone_number})
  end

  scope :public_user_external, ->(login_number) do
    joins(informations: :company).where(public_uid: login_number)
  end

  scope :employee_by_information, ->(information_id) do
    joins(:informations).where(information: {id: information_id})
  end

  scope :employees_by_meetings_desc, ->(company_id) do
    joins(:planning => :meetings)
        .joins("INNER JOIN information ON information.employee_id = employees.id AND information.company_id = meetings.company_id")
        .where(meetings: {company_id: company_id})
        .order("meetings.end_date desc").uniq
  end

  NATIONALITIES = {french: 0, european: 1, not_european: 2}
  # ======== NATIONALITY SCOPE ============= #
  scope :frenchs, -> () {
   where(nationality: NATIONALITIES[:french])
  }
  scope :europeans, -> () {
   where(nationality: NATIONALITIES[:european])
  }
  scope :not_europeans, -> () {
   where(nationality: NATIONALITIES[:not_european])
  }
  # ======== END NATIONALITIES SCOPE ========== #
  # ======== NATIONALITIES METHODS ============ #
  def french?
    nationality == NATIONALITIES[:french]
  end
  def european?
    nationality == NATIONALITIES[:european]
  end
  def not_european?
    nationality == NATIONALITIES[:not_european]
  end
  # ======== END NATIONALITIES METHODS ========== #

  def information_by_company company_id
    informations.find_by(company: company_id)
  end
  def detect_information_by_company company_id
    informations.detect{|i| i.company == company_id}
  end
end
