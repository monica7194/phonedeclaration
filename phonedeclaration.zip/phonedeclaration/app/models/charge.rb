class Charge < ApplicationRecord
  belongs_to :company
end
