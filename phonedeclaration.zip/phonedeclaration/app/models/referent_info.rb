class ReferentInfo < ApplicationRecord
  belongs_to :referent
  belongs_to :company

  def disabled?
    disabled_at.present?
  end
  def not_disabled?
    !disabled?
  end

  def disabled
    if disabled?
      self.update_attribute('disabled_at', nil)
    else
      self.update_attribute('disabled_at', Time.current)
    end
  end
end
