class Referent < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  has_many :referent_infos
  has_many :companies, through: :referent_infos
  accepts_nested_attributes_for :referent_infos

  validates :phone_number, length: {maximum: 10}, allow_blank: true
  validates :postal_code, length: {maximum: 5}, allow_blank: true

end
