class Company < ApplicationRecord
  UID_RANGE = ('0'..'9').to_a
  generate_public_uid generator: PublicUid::Generators::RangeString.new(6, UID_RANGE)
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  has_many :informations
  has_many :employees, through: :informations
  has_many :referent_infos
  has_many :referents, through: :referent_infos
  has_many :charges
  validate :social_security_number_format

  before_create do
    colors = ['red', 'pink', 'purple', 'deep-purple', 'indigo', 'blue', 'light-blue', 'cyan', 'teal', 'green', 'deep-orange', 'brown', 'blue-grey']
    color_opacities = ['500', '600', '700', '800']
    self.color = "#{colors.sample}-#{color_opacities.sample}"
  end
  def social_security_number_format
    #1 2 3 7 or 8 for sex
    #([0-9]{2}) birthdate year ( aa )
    #(0[0-9]|[2-35-9][0-9]|[14][0-2]) month (mm)
    #((0[1-9]|[1-8][0-9]|9[0-69]|2[abAB])(00[1-9]|0[1-9][0-9]|[1-8][0-9]{2}|9[0-8][0-9]|990)|(9[78][0-9])(0[1-9]|[1-8][0-9]|90)) postal code
    #(00[1-9]|0[1-9][0-9]|[1-9][0-9]{2}) birth order number
    #(0[1-9]|[1-8][0-9]|9[0-7]) key control
    sex = "([1-47-8])"
    birthdate_year = "([0-9]{2})"
    birthdate_month = "(0[0-9]|[2-35-9][0-9]|[14][0-2])"
    postal_code = "((0[1-9]|[1-8][0-9]|9[0-69]|2[abAB])(00[1-9]|0[1-9][0-9]|[1-8][0-9]{2}|9[0-8][0-9]|990)|(9[78][0-9])(0[1-9]|[1-8][0-9]|90))"
    birth_order_number = "(00[1-9]|0[1-9][0-9]|[1-9][0-9]{2})"
    key_control = "(0[1-9]|[1-8][0-9]|9[0-7])"
    valid_regex = Regexp.new("#{sex}#{birthdate_year}#{birthdate_month}#{postal_code}#{birth_order_number}#{key_control}")
    if french? &&social_security_number.present? and not social_security_number.match(valid_regex)
      errors.add :social_security_number, I18n.t("not_valid_format")
    end
  end

  def set_debitoor
    if debitoor_customer_id.blank?
      client = Debitoor.add_client email, email
      update debitoor_customer_id: client["id"]
    end
  end

  def total_missions
    total = 0
    employees.map do |employee|
      total += employee.pointing_flyers.joins(:meeting => [:company]).where(companies: {id: id}).length
    end
    total
  end

  def fullname
    self.firstname.to_s + ' ' + self.lastname.to_s
  end

  def fulladdress
    self.address_1.to_s + ',' + self.postal_code.to_s + ' ' + self.city.to_s + ', ' + self.country.to_s
  end

  def disabled?
    disabled_at.present?
  end
  def not_disabled?
    disabled_at.blank?
  end
  def disabled_date_not_past?
    disabled_at.blank? || disabled_at > DateTime.current
  end

  def disabled
    if disabled?
      update disabled_at: nil
    else
      disabled_date = DateTime.current.beginning_of_month.next_month
      self.informations.map do |information|
        information.update disabled_at: disabled_date
      end
      update disabled_at: disabled_date
    end
  end

  scope :public_user, ->(phone_number, login_number) do
    where(public_uid: login_number, phone_number: phone_number)
  end

  scope :public_user_external, ->(login_number) do
    where(public_uid: login_number)
  end

  NATIONALITIES = {french: 0, european: 1, not_european: 2}
  # ======== NATIONALITIES SCOPE ============= #
  scope :frenchs, -> () {
   where(nationality: NATIONALITIES[:french])
  }
  scope :europeans, -> () {
   where(nationality: NATIONALITIES[:european])
  }
  scope :not_europeans, -> () {
   where(nationality: NATIONALITIES[:not_european])
  }
  # ======== END NATIONALITIES SCOPE ========== #
  # ======== NATIONALITIES METHODS ============ #
  def french?
    nationality == NATIONALITIES[:french]
  end
  def european?
    nationality == NATIONALITIES[:european]
  end
  def not_european?
    nationality == NATIONALITIES[:not_european]
  end
  # ======== END NATIONALITIES METHODS ========== #

end
