class AdminInfo < ApplicationRecord
end
