class AdminPrice < ApplicationRecord
  # validate :check_one_fix
  validates :amount_for, :uniqueness => true
  validates :amount, :amount_for, presence: true
  validates :amount, :numericality => { :greater_than_or_equal_to => 0 }
  before_save do
    if show_order_changed?
      last = AdminPrice.ordered.last
      if (last.present? && show_order <= last.show_order && last.id != self.id)
        self.show_order = last.show_order + 1
      elsif last.blank?
        self.show_order = AdminPrice.count + 1
      end
    end
  end
  # def check_one_fix
  #   errors.add :amount_type, "only one amount fix possible" if AdminPrice.fixes.count > 1
  # end

  def self.nb_salaries_options
    [
      ["coup fixe", "coup fixe"],
      ["Société - 10 salariés", "Société - 10 salariés"],
      ["Société 10 - 20 salariés", "Société 10 - 20 salariés"],
      ["Société 21 - 50 salariés", "Société 21 - 50 salariés"],
      ["Société 51 - 100 salariés", "Société 51 - 100 salariés"],
      ["Société 100 - 300 salariés", "Société 100 - 300 salariés"],
      ["Société + 300 salariés", "Société + 300 salariés"]
    ]
  end
  AMOUNT_TYPES = {fix: 0, variable: 1}
  # ======== AMOUNT_TYPES SCOPE ============= #
  scope :fixes, -> () {
   where(amount_type: AMOUNT_TYPES[:fix])
  }
  scope :variables, -> () {
   where(amount_type: AMOUNT_TYPES[:variable])
  }
  scope :ordered, -> () {
    order(:show_order)
  }
  # ======== END AMOUNT_TYPES SCOPE ========== #

  # ======== AMOUNT_TYPES METHODS ============ #
  def fix?
    amount_type == AMOUNT_TYPES[:fix]
  end
  def variable?
    amount_type == AMOUNT_TYPES[:variable]
  end
  # ======== END PRICES METHODS ========== #

end
