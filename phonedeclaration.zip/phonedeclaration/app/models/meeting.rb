class Meeting < ApplicationRecord
  belongs_to :company, optional: true
  belongs_to :planning
  has_many :pointing_flyers
  validates :start_date, :end_date, :title, presence: true
  validate :end_date_after_start_date, :date_no_overlaps, :check_past_date, :check_pointing_flyers, :company_disabled
  before_create :generate_token

  before_validation do
    if self.end_date.blank?
      self.end_date = self.start_date + 1.hours if self.start_date.present?
    end

  end

  def generate_token
    self.token = SecureRandom.urlsafe_base64(nil, false)
    self.state = 0 if self.start_date <= 1.day.from_now && self.company_id.present?
  end

  after_create do
    if self.company.present?
      UserMailer.meeting_created(self).deliver_now if self.start_date <= 1.day.from_now
    else
      informations = self.planning.employee.informations
      informations.each do |information|
        UserMailer.meeting_created_day_off(self, information, information.company).deliver_now
      end
    end
  end

  after_update do
    if saved_change_to_attribute?(:state)
      case state
      when STATES[:accepted]
        UserMailer.meeting_accepted(self).deliver_now
      when STATES[:refused]
        UserMailer.meeting_refused(self).deliver_now
      end
    end
  end
  DAY_OFF_REASON = {day_off: 0, sick_leave: 1}
  # ======== DAY_OF_REASON SCOPE ============= #
  scope :day_offs, -> () {
   where(day_off_reason: DAY_OFF_REASON[:day_off])
  }
  scope :sick_leaves, -> () {
   where(day_off_reason: DAY_OFF_REASON[:sick_leave])
  }
  # ======== END DAY_OF_REASON SCOPE ========== #
  # ======== DAY_OF_REASON METHODS ============ #
  def day_off?
    day_off_reason == DAY_OFF_REASON[:day_off]
  end
  def sick_leave?
    day_off_reason == DAY_OFF_REASON[:sick_leave]
  end
  # ======== END DAY_OF_REASON METHODS ========== #

  STATES = {pending: 0, accepted: 1, refused: 2}
  # ======== STATES SCOPE ============= #
  scope :pendings, -> () {
   where(state: STATES[:pending])
  }
  scope :accepteds, -> () {
   where(state: STATES[:accepted])
  }
  scope :refuseds, -> () {
   where(state: STATES[:refused])
  }
  # ======== END STATES SCOPE ========== #
  # ======== STATES METHODS ============ #
  def pending?
    state == STATES[:pending]
  end
  def accepted?
    state == STATES[:accepted]
  end
  def refused?
    state == STATES[:refused]
  end
  # ======== END STATES METHODS ========== #

  def date_no_overlaps
    if start_date_changed? || end_date_changed?
      meetings_overlaps = Meeting.where.not(id: id).where('(start_date <= ? AND end_date >= ?)', end_date, start_date).where(planning_id: planning_id)
      errors.add :start_date, "Une mission ou un congé existe déjà à cette date" if meetings_overlaps.present?
    end
  end

  def end_date_after_start_date
    if end_date.present? && start_date.present? && end_date < start_date
      errors.add :end_date, I18n.t("must_be_after_start_date")
    end
  end
  def check_past_date
    if start_date.present? && start_date < DateTime.current + 59.minutes
      errors.add :start_date, I18n.t("is_past")
    end
  end
  def company_disabled
    company = Company.find(self.company_id) if self.company_id.present?
    if start_date.present? && company.present? && company.disabled? && (start_date >= company.disabled_at)
      errors.add :start_date, "La mission ne peut pas être crée ou mofifée car le compte employeur est désactivé"
    end
  end

  def check_pointing_flyers
    if company_id.blank? && company_id_changed?
      if pointing_flyers.present?
        errors.add :day_off_reason, "Ne peut pas etre modifié car la mission a commencée"
      end
    end
  end

  def calendar_json company_id = nil
    {
      meeting_id: id,
      title: (company_id.present? ? (company_id == self.company_id ? title : '') : title),
      start: start_date.strftime('%a, %d %b %Y %H:%M:%S'),
      end: end_date.strftime('%a, %d %b %Y %H:%M:%S'),
      className: company.present? ? company.color : 'light',
      allDay: false,
      company_id: (self.company_id.present? ? self.company_id : day_off_reason),
      editable: (company_id.present? ? (company_id == self.company_id) : true),
      state: state
    }
  end

  def calendar_company_json company_id
    {
      meeting_id: id,
      title: company_id == self.company_id ? title : '',
      start: start_date.strftime('%a, %d %b %Y %H:%M:%S'),
      end: end_date.strftime('%a, %d %b %Y %H:%M:%S'),
      className: company.present? ? company.color : 'light',
      allDay: false,
      company_id: (self.company_id.present? ? company_id : day_off_reason),
      editable: (company_id == self.company_id && (start_date > Date.current() && end_date > Date.current())) ? true : false,
      color: (company_id == self.company_id) ? '#0b8043' : '#4285f4',
      state: state
    }
  end

  def serializeSVI
    json = self.as_json.except!("start_date", "end_date")
    json.merge!({
                    start_date: start_date.strftime("%d/%m/%Y à %H heures %M"),
                    end_date: end_date.strftime("%d/%m/%Y à %H heures %M"),
                    planning: planning
                })
  end

  def update_state_by_email state, token_used
    if token_used
      update_columns( state: state, token: nil, token_used_date: Time.current) if token != nil
    else
      update_columns( state: state, token: nil, token_expired_date: Time.current) if token != nil
    end
    case state
    when STATES[:accepted]
      UserMailer.meeting_accepted(self).deliver_now
    when STATES[:refused]
      UserMailer.meeting_refused(self).deliver_now
    end
  end

  scope :current_mission, ->(current_employee_id) {
    joins(:planning, :pointing_flyers)
    .where("plannings.employee_id = :current_employee_id AND pointing_flyers.job_in_progress = true", {current_employee_id: current_employee_id})
    .where(state: STATES[:accepted])
  }

  scope :next_mission, ->(current_date, current_employee_id) {
    joins("INNER JOIN plannings ON plannings.id = meetings.planning_id AND plannings.employee_id = '#{current_employee_id}'")
    .where("meetings.start_date <= :current_date AND meetings.end_date >= :current_date", {current_date: current_date})
    .where(state: STATES[:accepted])
  }

  scope :current_mission_by_company, ->(employee_id, company_id) do
    joins(:planning, :pointing_flyers)
    .where(meetings: {
        state: STATES[:accepted],
        company_id: company_id,
        plannings: {employee_id: employee_id},
    })
    .where("meetings.start_date <= :current_date AND meetings.end_date >= :current_date", {current_date: DateTime.current})
  end

  scope :last_mission_by_company, ->(employee_id, company_id) do
    joins(:planning, :pointing_flyers)
    .where(meetings: {
        state: STATES[:accepted],
        company_id: company_id,
        plannings: {employee_id: employee_id},
        pointing_flyers: {job_in_progress: false}
    })
    .order(:updated_at)
  end

  scope :current_mission_by_employee, ->(employee_id) do
    joins(:planning, :pointing_flyers)
    .where(meetings: {
        state: STATES[:accepted],
        plannings: {employee_id: employee_id},
    })
    .where("meetings.start_date <= :current_date AND meetings.end_date >= :current_date", {current_date: DateTime.current})
  end

  scope :current_mission_started_by_company, ->(employee_id, company_id) do
    joins(:planning, :pointing_flyers)
    .where(meetings: {
        state: STATES[:accepted],
        company_id: company_id,
        plannings: {employee_id: employee_id},
        pointing_flyers: {job_in_progress: true}
    })
  end

  scope :current_mission_started_by_employee, ->(employee_id) do
    joins(:planning, :pointing_flyers)
    .where(meetings: {
        state: STATES[:accepted],
        plannings: {employee_id: employee_id},
        pointing_flyers: {job_in_progress: true}
    })
  end

  # scope :monthly_active_employees, ->(current_company_id) do
  #   joins(:plannings, :employees)
  #   .where("company_id = :current_company_id", {current_company_id: current_company_id})
  # end

end
