class UserMailer < ApplicationMailer
  def employee_registration employee, password
    @employee = employee
    @password = password
    mail(to: employee.email, subject: 'Bienvenue')
  end

  def referent_registration referent, password
    @referent = referent
    @password = password
    mail(to: referent.email, subject: 'Votre compte référent vient d\'être crée')
  end

  def company_registration company, password
    @company = company
    @password = password
    mail(to: company.email, subject: 'Votre compte employeur vient d\'être crée')
  end

  def admin_registration admin, password
    @admin = admin
    @password = password
    mail(to: admin.email, subject: 'Votre compte administrateur vient d\'être crée')
  end

  def meeting_created meeting
    @meeting = meeting
    mail(to: meeting.planning.employee.email, subject: 'Une nouvelle mission a été crée')
  end
  def meeting_created_day_off meeting, information, company
    @meeting = meeting
    @information = information
    mail(to: company.email, subject: 'Un employé à pris un jour')
  end
  def meeting_accepted meeting
    @meeting = meeting
    mail(to: meeting.company.email, subject: 'Une nouvelle mission a été acceptée')
  end
  def meeting_refused meeting
    @meeting = meeting
    mail(to: meeting.company.email, subject: 'Une nouvelle mission a été refusée')
  end

  def pointing_flyer_late_company pointing_flyer
    @information = pointing_flyer.employee.information_by_company(company: meeting.company.id)
    @pointing_flyer = pointing_flyer
    @meeting = pointing_flyer.meeting
    mail(to: @meeting.company.email, subject: 'Un employé est en retard')
  end
  def pointing_flyer_late_employee pointing_flyer
    @information = pointing_flyer.employee.information_by_company(company: meeting.company.id)
    @pointing_flyer = pointing_flyer
    @meeting = pointing_flyer.meeting
    mail(to: @meeting.company.email, subject: 'Un employé est en retard')
  end
end
