class PresenceCheckerMailer < ApplicationMailer
  def delay_start_mission_company meeting, information
    @meeting = meeting
    @information = information
    mail(to: meeting.company.email, subject: 'Retard de votre employé(e)')
  end
  def delay_start_mission_employee meeting, information
    @meeting = meeting
    @information = information
    mail(to: information.employee.email, subject: 'Vous êtes en retard')
  end
  def delay_end_mission_company meeting, information
    @meeting = meeting
    @information = information
    mail(to: meeting.company.email, subject: 'Retard de votre employé(e)')
  end
  def delay_end_mission_employee meeting, information
    @meeting = meeting
    @information = information
    mail(to: information.employee.email, subject: 'Vous êtes en retard')
  end
  # Send test mail to test CRON execution
  def test_mail
    @recipient = 'anthony@kamini.io'
    mail(to: 'anthony@kamini.io', subject: 'Test mail send via CRON')
  end
end
