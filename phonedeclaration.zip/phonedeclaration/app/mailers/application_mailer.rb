class ApplicationMailer < ActionMailer::Base
  default from: ENV['email_contact']
  layout 'mailer'
end
