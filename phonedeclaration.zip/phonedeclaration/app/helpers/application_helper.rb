module ApplicationHelper
  def li_active_link_to content, path, options= {}
    active = current_page?(path) ? "active" : ""
    content_tag :li, class: active do
      link_to content, path, options
    end
  end

  def active_class(wanted, type)
    wanted = wanted.split(', ') if [:controller, :action].include?(type)
    case type
    when :path
      current_page?(wanted) ? "active" : ""
    when :controller
      wanted.include?(controller_name) ? "active" : ""
    when :action
      wanted.include?(action_name) ? "active" : ""
    when :action_controller
      wanted == "#{controller_name}_#{action_name}" ? "active" : ""
    else
      ""
    end
  end

  # Get time diff between 2 dates.
  #
  # @see https://stackoverflow.com/a/19596579
  def time_diff(start_time, end_time)
    seconds_diff = (start_time - end_time).to_i.abs

    hours = seconds_diff / 3600
    seconds_diff -= hours * 3600

    minutes = seconds_diff / 60
    seconds_diff -= minutes * 60

    seconds = seconds_diff

    "#{hours.to_s.rjust(2, '0')}h#{minutes.to_s.rjust(2, '0')}min#{seconds.to_s.rjust(2, '0')}sec"
    # or, as hagello suggested in the comments:
    # '%02d:%02d:%02d' % [hours, minutes, seconds]
  end
  def second_diff(seconds_diff)
    seconds_diff = seconds_diff.to_i.abs
    hours = seconds_diff / 3600
    seconds_diff -= hours * 3600

    minutes = seconds_diff / 60
    seconds_diff -= minutes * 60

    seconds = seconds_diff

    "#{hours.to_s.rjust(2, '0')}h#{minutes.to_s.rjust(2, '0')}min#{seconds.to_s.rjust(2, '0')}sec"
    # or, as hagello suggested in the comments:
    # '%02d:%02d:%02d' % [hours, minutes, seconds]
  end

  # Get time diff between 2 dates.
  #
  # @see https://stackoverflow.com/a/19596579
  def format_duration_to_time(seconds_diff)

    hours = seconds_diff / 3600
    seconds_diff -= hours * 3600

    minutes = seconds_diff / 60
    seconds_diff -= minutes * 60

    seconds = seconds_diff

    "#{hours.to_s.rjust(2, '0')} heures et #{minutes.to_s.rjust(2, '0')} minutes"
  end

end
